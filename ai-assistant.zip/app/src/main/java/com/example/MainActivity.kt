package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.model.AppInfo
import com.example.model.ChatMessage
import com.example.model.LaprriLanguage
import com.example.model.UploadedFileItem
import com.example.model.UploadedFileType
import com.example.ui.theme.MyApplicationTheme
import com.example.util.LaprriVoiceManager
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                LaprriLiveWallpaperApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LaprriLiveWallpaperApp() {
    val context = LocalContext.current
    var is3DLoading by remember { mutableStateOf(true) }
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var showControlsOverlay by remember { mutableStateOf(true) }
    var showAccessSettingsSheet by remember { mutableStateOf(false) }
    var showFileUploadSheet by remember { mutableStateOf(false) }
    var appSearchQuery by remember { mutableStateOf("") }

    val voiceManager = remember { LaprriVoiceManager(context) }
    val isSpeaking by voiceManager.isSpeaking.collectAsState()
    val isListening by voiceManager.isListening.collectAsState()
    val isBluetoothConnected by voiceManager.isBluetoothConnected.collectAsState()
    val bluetoothDeviceName by voiceManager.bluetoothDeviceName.collectAsState()
    val currentDialogue by voiceManager.currentDialogue.collectAsState()
    val isVoiceEnabled by voiceManager.isVoiceEnabled.collectAsState()
    val hasCustomAudio by voiceManager.hasCustomAudio.collectAsState()
    val currentLanguage by voiceManager.currentLanguage.collectAsState()
    val rmsVolume by voiceManager.rmsVolume.collectAsState()
    val customWallpaperPath by voiceManager.customWallpaperPath.collectAsState()
    val uploadedFiles by voiceManager.uploadedFiles.collectAsState()
    val chatMessages by voiceManager.chatMessages.collectAsState()
    var showChatSheet by remember { mutableStateOf(false) }
    var chatInputText by remember { mutableStateOf("") }

    var hasRecordAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    // Access states & Installed apps
    val isPhoneAccessEnabled by voiceManager.isPhoneAccessEnabled.collectAsState()
    val pendingPermissionApp by voiceManager.pendingPermissionApp.collectAsState()
    val installedApps by voiceManager.installedApps.collectAsState()

    // Multiple Permission launcher
    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val recordAudioGranted = permissions[Manifest.permission.RECORD_AUDIO]
            ?: (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
        hasRecordAudioPermission = recordAudioGranted
        voiceManager.setPermissionGranted(recordAudioGranted)
        voiceManager.checkBluetoothAudioRouting()
        voiceManager.loadInstalledApps()
    }

    LaunchedEffect(Unit) {
        val permissionsToRequest = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissionsToRequest.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionsToRequest.add(Manifest.permission.READ_MEDIA_IMAGES)
            permissionsToRequest.add(Manifest.permission.READ_MEDIA_VIDEO)
        }

        val missingPermissions = permissionsToRequest.filter { perm ->
            ContextCompat.checkSelfPermission(context, perm) != PackageManager.PERMISSION_GRANTED
        }

        if (missingPermissions.isEmpty()) {
            hasRecordAudioPermission = true
            voiceManager.setPermissionGranted(true)
        } else {
            permissionsLauncher.launch(permissionsToRequest.toTypedArray())
        }
        voiceManager.loadInstalledApps()
    }

    // Audio Picker for custom voice / recording
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            voiceManager.uploadFile(uri, "voice_audio")
        }
    }

    // Image Picker for custom photo wallpaper
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            voiceManager.setCustomWallpaper(uri)
        }
    }

    // Generic File Picker for any document/file
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            voiceManager.uploadFile(uri)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            voiceManager.shutdown()
        }
    }

    // Live wallpaper HTML: Pure Pitch Black background (#000000), seamless auto-spin loop, touch pass-through & full animated pose
    val embedHtml = remember {
        """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
            <style>
                * {
                    box-sizing: border-box;
                    margin: 0;
                    padding: 0;
                    user-select: none;
                    -webkit-user-select: none;
                }
                html, body {
                    width: 100%;
                    height: 100%;
                    background-color: transparent !important;
                    background: transparent !important;
                    overflow: hidden;
                    touch-action: none;
                    pointer-events: none;
                }
                .sketchfab-embed-wrapper {
                    width: 100%;
                    height: 100%;
                    position: absolute;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background-color: transparent !important;
                    background: transparent !important;
                    pointer-events: none;
                }
                #api-frame {
                    width: 100%;
                    height: 100%;
                    border: 0;
                    display: block;
                    background-color: transparent !important;
                    background: transparent !important;
                    pointer-events: none;
                }
            </style>
            <script type="text/javascript" src="https://static.sketchfab.com/api/sketchfab-viewer-1.12.1.js"></script>
        </head>
        <body>
            <div class="sketchfab-embed-wrapper">
                <iframe id="api-frame" title="Laprri 3D Animated" frameborder="0" allowfullscreen mozallowfullscreen="true" webkitallowfullscreen="true" allow="autoplay; fullscreen; xr-spatial-tracking" xr-spatial-tracking execution-while-out-of-viewport execution-while-not-rendered web-share src="https://sketchfab.com/models/6dbe3e3dc6704a36bb3acef80b0bc5e4/embed?autostart=1&autospin=0.35&preload=1&transparent=1&ui_animations=1&ui_controls=0&ui_infos=0&ui_watermark=0&ui_theme=dark&ui_hint=0"></iframe>
            </div>
            <script type="text/javascript">
                function initViewer() {
                    var iframe = document.getElementById('api-frame');
                    var version = '1.12.1';
                    var client = new Sketchfab(version, iframe);

                    client.init('6dbe3e3dc6704a36bb3acef80b0bc5e4', {
                        success: function onSuccess(api) {
                            api.start(function() {
                                api.addEventListener('viewerready', function() {
                                    api.setBackground({ color: [0, 0, 0, 0] }, function() {});
                                    api.setFov(45, function() {});
                                    api.getAnimations(function(err, animations) {
                                        if (!err && animations && animations.length > 0) {
                                            api.setCurrentAnimationByUID(animations[0].uid, function() {
                                                api.play(function() {});
                                            });
                                        }
                                    });
                                });
                            });
                        },
                        error: function onError() {},
                        autostart: 1,
                        autospin: 0.35,
                        preload: 1,
                        transparent: 1,
                        ui_animations: 0,
                        ui_controls: 0,
                        ui_infos: 0,
                        ui_watermark: 0,
                        ui_theme: 'dark',
                        ui_hint: 0
                    });
                }
                document.addEventListener('DOMContentLoaded', initViewer);
            </script>
        </body>
        </html>
        """.trimIndent()
    }

    // Sound wave animations
    val infiniteTransition = rememberInfiniteTransition(label = "voice_wave")
    val waveHeight1 by infiniteTransition.animateFloat(
        initialValue = 6f,
        targetValue = 24f,
        animationSpec = infiniteRepeatable(
            animation = tween(380, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "w1"
    )
    val waveHeight2 by infiniteTransition.animateFloat(
        initialValue = 18f,
        targetValue = 8f,
        animationSpec = infiniteRepeatable(
            animation = tween(420, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "w2"
    )
    val waveHeight3 by infiniteTransition.animateFloat(
        initialValue = 10f,
        targetValue = 28f,
        animationSpec = infiniteRepeatable(
            animation = tween(350, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "w3"
    )

    val listeningPulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                showControlsOverlay = !showControlsOverlay
            }
    ) {
        // 1. Custom Image / Photo Wallpaper (if uploaded/selected by user)
        if (customWallpaperPath != null) {
            AsyncImage(
                model = File(customWallpaperPath!!),
                contentDescription = "Custom Photo Wallpaper",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Subtle dark overlay to ensure readability & contrast
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.38f))
            )
        }

        // Pure Pitch Black or Floating 3D Animated Live Wallpaper
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    setBackgroundColor(android.graphics.Color.TRANSPARENT)
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        loadWithOverviewMode = true
                        useWideViewPort = true
                        builtInZoomControls = false
                        displayZoomControls = false
                        allowFileAccess = true
                        allowContentAccess = true
                        setSupportZoom(false)
                        databaseEnabled = true
                        cacheMode = WebSettings.LOAD_DEFAULT
                        mediaPlaybackRequiresUserGesture = false
                    }
                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            is3DLoading = true
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            is3DLoading = false
                        }

                        override fun shouldOverrideUrlLoading(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): Boolean {
                            return false
                        }
                    }
                    webChromeClient = WebChromeClient()
                    loadDataWithBaseURL("https://sketchfab.com", embedHtml, "text/html", "UTF-8", null)
                    webViewInstance = this
                    setOnTouchListener { _, _ -> false }
                }
            }
        )

        // Loading Indicator Overlay
        if (is3DLoading) {
            Surface(
                color = Color(0xEB000000),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(
                        color = Color(0xFF2DD4BF),
                        modifier = Modifier.size(36.dp),
                        strokeWidth = 3.dp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Loading Laprri 3D Wallpaper...",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Top Minimalist Controls Bar & Emergency Alerts
        AnimatedVisibility(
            visible = showControlsOverlay,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .align(Alignment.TopCenter)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Title Pill
                    Surface(
                        color = Color(0xCC0A0A0A),
                        shape = RoundedCornerShape(20.dp),
                        shadowElevation = 6.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isSpeaking) Color(0xFF34D399)
                                        else if (isListening) Color(0xFF2DD4BF).copy(alpha = listeningPulseAlpha)
                                        else Color(0xFF71717A)
                                    )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Laprri",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "• ${currentLanguage.nativeName}",
                                color = Color(0xFF2DD4BF),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // 3-Language Switcher Button (Gujarati, Hindi, English)
                        Surface(
                            color = Color(0xFF0F766E),
                            shape = RoundedCornerShape(16.dp),
                            shadowElevation = 6.dp,
                            modifier = Modifier.clickable {
                                val nextLang = when (currentLanguage) {
                                    LaprriLanguage.GUJARATI -> LaprriLanguage.HINDI
                                    LaprriLanguage.HINDI -> LaprriLanguage.ENGLISH
                                    LaprriLanguage.ENGLISH -> LaprriLanguage.GUJARATI
                                }
                                voiceManager.setLanguage(nextLang, notifyUser = true)
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Language,
                                    contentDescription = "Switch Language",
                                    tint = Color(0xFF5EEAD4),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = currentLanguage.nativeName,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        // App Permissions & Access Control Button
                        Surface(
                            color = if (isPhoneAccessEnabled) Color(0xFF0F766E) else Color(0xCC27272A),
                            shape = CircleShape,
                            shadowElevation = 6.dp,
                            modifier = Modifier.size(36.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    voiceManager.loadInstalledApps()
                                    showAccessSettingsSheet = true
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = "App Permissions Manager",
                                    tint = if (isPhoneAccessEnabled) Color(0xFF5EEAD4) else Color(0xFFA1A1AA),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        // Bluetooth Status Indicator
                        Surface(
                            color = if (isBluetoothConnected) Color(0xFF2563EB) else Color(0xCC18181B),
                            shape = CircleShape,
                            shadowElevation = 6.dp,
                            modifier = Modifier.size(36.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    voiceManager.checkBluetoothAudioRouting()
                                    val feedback = if (isBluetoothConnected) {
                                        "🎧 Bluetooth Active: ${bluetoothDeviceName ?: "Headset"}"
                                    } else {
                                        "🔍 Bluetooth checked: Microphone is ready."
                                    }
                                    voiceManager.deliverResponse(feedback)
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = if (isBluetoothConnected) Icons.Default.BluetoothConnected else Icons.Default.Bluetooth,
                                    contentDescription = "Bluetooth Status",
                                    tint = if (isBluetoothConnected) Color.White else Color(0xFF94A3B8),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        // Chat Assistant Button
                        Surface(
                            color = if (chatMessages.size > 1) Color(0xFF0F766E) else Color(0xCC18181B),
                            shape = CircleShape,
                            shadowElevation = 6.dp,
                            modifier = Modifier.size(36.dp)
                        ) {
                            IconButton(
                                onClick = { showChatSheet = true },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Chat,
                                    contentDescription = "Chat Assistant",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        // File, Image & Wallpaper Upload Hub
                        Surface(
                            color = if (uploadedFiles.isNotEmpty() || customWallpaperPath != null) Color(0xFF0D9488) else Color(0xCC18181B),
                            shape = CircleShape,
                            shadowElevation = 6.dp,
                            modifier = Modifier.size(36.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    voiceManager.loadUploadedFiles()
                                    showFileUploadSheet = true
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CloudUpload,
                                    contentDescription = "Upload Images, Wallpapers and Files",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        // Voice Mute/Unmute Toggle
                        Surface(
                            color = if (isVoiceEnabled) Color(0xFF0D9488) else Color(0xCC18181B),
                            shape = CircleShape,
                            shadowElevation = 6.dp,
                            modifier = Modifier.size(36.dp)
                        ) {
                            IconButton(
                                onClick = { voiceManager.toggleVoice() },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = if (isVoiceEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                                    contentDescription = "Toggle Voice",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        // Refresh Button
                        Surface(
                            color = Color(0xCC18181B),
                            shape = CircleShape,
                            shadowElevation = 6.dp,
                            modifier = Modifier.size(36.dp)
                        ) {
                            IconButton(
                                onClick = { webViewInstance?.reload() },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Reload",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }

                // If microphone permission is missing, show an unmistakable prompt banner
                if (!hasRecordAudioPermission) {
                    Surface(
                        color = Color(0xEEB91C1C),
                        shape = RoundedCornerShape(12.dp),
                        shadowElevation = 6.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 4.dp)
                            .clickable {
                                permissionsLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.RECORD_AUDIO
                                    )
                                )
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.MicOff,
                                contentDescription = "Mic Permission Missing",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Microphone Permission Required",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = "Tap here to allow mic permission so Laprri can hear your voice commands!",
                                    color = Color(0xFFFEE2E2),
                                    fontSize = 10.5.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Bottom Voice & Pending Permission Alert Cards
        AnimatedVisibility(
            visible = showControlsOverlay,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Interactive Pending Permission Prompt Card (When Laprri asks user in selected language)
                AnimatedVisibility(
                    visible = pendingPermissionApp != null,
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val app = pendingPermissionApp
                    if (app != null) {
                        val promptText = when (currentLanguage) {
                            LaprriLanguage.GUJARATI -> "\"સર, ${app.appName} ની પરમિશન મારી પાસે નથી. શું હું આ એપની પરમિશન આપી દઉં?\""
                            LaprriLanguage.HINDI -> "\"सर, ${app.appName} की परमिशन मेरे पास नहीं है। क्या मैं इसकी परमिशन अलाउ कर दूँ?\""
                            LaprriLanguage.ENGLISH -> "\"Sir, I don't have permission for ${app.appName}. Should I grant permission for it?\""
                        }
                        val allowBtnText = when (currentLanguage) {
                            LaprriLanguage.GUJARATI -> "હા, આપી દો (Voice)"
                            LaprriLanguage.HINDI -> "हाँ, दे दो (Voice)"
                            LaprriLanguage.ENGLISH -> "Yes, Allow (Voice)"
                        }
                        val denyBtnText = when (currentLanguage) {
                            LaprriLanguage.GUJARATI -> "ના, રહેવા દો"
                            LaprriLanguage.HINDI -> "नहीं, मत दो"
                            LaprriLanguage.ENGLISH -> "No, Deny"
                        }

                        Surface(
                            color = Color(0xF01E1B4B),
                            shape = RoundedCornerShape(18.dp),
                            shadowElevation = 10.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = "Permission Required",
                                        tint = Color(0xFFF59E0B),
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Permission Required: ${app.appName}",
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = promptText,
                                    color = Color(0xFFC7D2FE),
                                    fontSize = 13.sp,
                                    lineHeight = 18.sp
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = { voiceManager.confirmPendingPermission(true) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Allow",
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(text = allowBtnText, fontSize = 12.sp)
                                    }
                                    OutlinedButton(
                                        onClick = { voiceManager.confirmPendingPermission(false) },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Deny",
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(text = denyBtnText, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                // Voice Assistant Status Badge
                Surface(
                    color = if (isBluetoothConnected) Color(0xCC1D4ED8) else if (isPhoneAccessEnabled) Color(0xCC0D9488) else Color(0xCC3F3F46),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isBluetoothConnected) Icons.Default.BluetoothConnected else if (isPhoneAccessEnabled) Icons.Default.Hearing else Icons.Default.Security,
                            contentDescription = "Audio routing",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isBluetoothConnected) {
                                "🎧 Bluetooth Active: ${bluetoothDeviceName ?: "Headset"}"
                            } else if (isPhoneAccessEnabled) {
                                when (currentLanguage) {
                                    LaprriLanguage.GUJARATI -> "🎙️ લપરી: 'WhatsApp ખોલો' અથવા 'YouTube ચાલુ કરો' બોલો"
                                    LaprriLanguage.HINDI -> "🎙️ लपरी: 'WhatsApp खोलो' या 'YouTube चलाओ' बोलिए"
                                    LaprriLanguage.ENGLISH -> "🎙️ Laprri: Speak any app (e.g. 'Open WhatsApp')"
                                }
                            } else {
                                "🔒 Phone Access Disabled (Say 'Access On')"
                            },
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Laprri Response Card
                Surface(
                    color = Color(0xE6101010),
                    shape = RoundedCornerShape(20.dp),
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { voiceManager.forceListenNow() }
                        .testTag("laprri_voice_card")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isSpeaking) Color(0xFF0D9488)
                                    else if (isBluetoothConnected) Color(0xFF1E40AF)
                                    else Color(0xFF27272A)
                                )
                        ) {
                            if (isSpeaking) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .width(3.dp)
                                            .height(waveHeight1.dp)
                                            .clip(CircleShape)
                                            .background(Color.White)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .width(3.dp)
                                            .height(waveHeight2.dp)
                                            .clip(CircleShape)
                                            .background(Color.White)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .width(3.dp)
                                            .height(waveHeight3.dp)
                                            .clip(CircleShape)
                                            .background(Color.White)
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = if (isBluetoothConnected) Icons.Default.Bluetooth else if (hasCustomAudio) Icons.Default.Mic else Icons.Default.GraphicEq,
                                    contentDescription = "Voice",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Laprri",
                                    color = Color(0xFF2DD4BF),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                if (isSpeaking) {
                                    Text(
                                        text = "• Speaking",
                                        color = Color(0xFF34D399),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                } else if (isListening) {
                                    Text(
                                        text = if (isBluetoothConnected) "• BT Mic Listening" else "• Listening...",
                                        color = if (isBluetoothConnected) Color(0xFF93C5FD) else Color(0xFF34D399),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(1.dp))
                            Text(
                                text = currentDialogue,
                                color = Color.White,
                                fontSize = 12.sp,
                                maxLines = 2,
                                lineHeight = 16.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Tap-To-Speak Mic Button
                        Surface(
                            color = if (isListening) Color(0xFF2563EB) else Color(0xFF0D9488),
                            shape = CircleShape,
                            modifier = Modifier.size(36.dp)
                        ) {
                            IconButton(
                                onClick = { voiceManager.forceListenNow() },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Tap to speak",
                                    tint = Color.White,
                                    modifier = Modifier.size(19.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        Surface(
                            color = Color(0xFF27272A),
                            shape = CircleShape,
                            modifier = Modifier.size(34.dp)
                        ) {
                            IconButton(
                                onClick = { voiceManager.triggerWakeResponse() },
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = "Play response",
                                    tint = Color.White,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Interactive Chat & Command Input Box
                Surface(
                    color = Color(0xF018181B),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, Color(0x332DD4BF)),
                    shadowElevation = 8.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { showChatSheet = true },
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Chat,
                                contentDescription = "Open Chat History",
                                tint = if (chatMessages.size > 1) Color(0xFF2DD4BF) else Color(0xFFA1A1AA),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        BasicTextField(
                            value = chatInputText,
                            onValueChange = { chatInputText = it },
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 8.dp, vertical = 8.dp)
                                .testTag("chat_input_field"),
                            textStyle = TextStyle(
                                color = Color.White,
                                fontSize = 13.sp
                            ),
                            cursorBrush = SolidColor(Color(0xFF2DD4BF)),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(
                                onSend = {
                                    if (chatInputText.isNotBlank()) {
                                        voiceManager.sendTextMessage(chatInputText)
                                        chatInputText = ""
                                    }
                                }
                            ),
                            decorationBox = { innerTextField ->
                                if (chatInputText.isEmpty()) {
                                    Text(
                                        text = when (currentLanguage) {
                                            LaprriLanguage.GUJARATI -> "અહીં લખીને પૂછો અથવા આદેશ આપો..."
                                            LaprriLanguage.HINDI -> "यहाँ लिखकर पूछें या कमांड दें..."
                                            LaprriLanguage.ENGLISH -> "Type command or question..."
                                        },
                                        color = Color(0xFF71717A),
                                        fontSize = 12.sp
                                    )
                                }
                                innerTextField()
                            }
                        )

                        IconButton(
                            onClick = {
                                if (chatInputText.isNotBlank()) {
                                    voiceManager.sendTextMessage(chatInputText)
                                    chatInputText = ""
                                }
                            },
                            enabled = chatInputText.isNotBlank(),
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("chat_send_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Send",
                                tint = if (chatInputText.isNotBlank()) Color(0xFF2DD4BF) else Color(0xFF52525B),
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }
                }
            }
        }

        // Full Phone Apps Permissions & Voice Access Sheet
        if (showAccessSettingsSheet) {
            ModalBottomSheet(
                onDismissRequest = { showAccessSettingsSheet = false },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                containerColor = Color(0xFF18181B)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .padding(bottom = 32.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Laprri Settings & Permissions",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "3 Languages • Voice Launcher • Permissions",
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp
                            )
                        }
                        IconButton(onClick = { showAccessSettingsSheet = false }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Language Selector Card (Gujarati, Hindi, English)
                    Surface(
                        color = Color(0xFF27272A),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Language,
                                    contentDescription = "Language",
                                    tint = Color(0xFF2DD4BF),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Choose Voice Language / ભાષા / भाषा",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                LaprriLanguage.entries.forEach { lang ->
                                    val isSelected = currentLanguage == lang
                                    Surface(
                                        color = if (isSelected) Color(0xFF0D9488) else Color(0xFF18181B),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { voiceManager.setLanguage(lang, notifyUser = true) }
                                            .then(
                                                if (isSelected) Modifier.border(1.5.dp, Color(0xFF5EEAD4), RoundedCornerShape(10.dp))
                                                else Modifier
                                            )
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(vertical = 10.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(
                                                text = lang.nativeName,
                                                color = if (isSelected) Color.White else Color(0xFFCBD5E1),
                                                fontSize = 13.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                            )
                                            Text(
                                                text = lang.displayName,
                                                color = if (isSelected) Color(0xFFCCFBF1) else Color(0xFF71717A),
                                                fontSize = 10.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Master Phone Access Switch
                    Surface(
                        color = Color(0xFF27272A),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = "Master Access",
                                    tint = if (isPhoneAccessEnabled) Color(0xFF2DD4BF) else Color(0xFF71717A),
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Master Phone Voice Access",
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (isPhoneAccessEnabled) "ON (Voice commands active)" else "OFF (All commands blocked)",
                                        color = if (isPhoneAccessEnabled) Color(0xFF2DD4BF) else Color(0xFFEF4444),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                            Switch(
                                checked = isPhoneAccessEnabled,
                                onCheckedChange = { voiceManager.setPhoneAccessEnabled(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFF0D9488)
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quick Bulk Permission Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { voiceManager.grantAllPermissions() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LockOpen,
                                contentDescription = "Allow All",
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Allow All Apps", fontSize = 11.sp)
                        }
                        OutlinedButton(
                            onClick = { voiceManager.revokeAllPermissions() },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = "Revoke All",
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Revoke All", fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Search Installed Apps
                    OutlinedTextField(
                        value = appSearchQuery,
                        onValueChange = { appSearchQuery = it },
                        placeholder = { Text("Search installed apps...", color = Color(0xFF71717A), fontSize = 13.sp) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        trailingIcon = {
                            if (appSearchQuery.isNotEmpty()) {
                                IconButton(onClick = { appSearchQuery = "" }) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Clear",
                                        tint = Color(0xFF94A3B8),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF2DD4BF),
                            unfocusedBorderColor = Color(0xFF3F3F46),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    val filteredApps = remember(installedApps, appSearchQuery) {
                        if (appSearchQuery.isBlank()) installedApps
                        else installedApps.filter {
                            it.appName.contains(appSearchQuery, ignoreCase = true) ||
                            it.packageName.contains(appSearchQuery, ignoreCase = true)
                        }
                    }

                    Text(
                        text = "Phone Apps (${filteredApps.size}):",
                        color = Color(0xFFCBD5E1),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Installed Apps List
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 240.dp)
                    ) {
                        items(filteredApps, key = { it.packageName }) { app ->
                            AppPermissionRowItem(
                                app = app,
                                isMasterEnabled = isPhoneAccessEnabled,
                                onToggle = { voiceManager.toggleAppPermission(app) }
                            )
                            HorizontalDivider(color = Color(0xFF27272A))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        color = Color(0xFF0F172A),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "🗣️ Voice Commands (3 Languages):",
                                color = Color(0xFF38BDF8),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "• ગુજરાતી: \"Laprri Gujarati ma bolo\", \"WhatsApp ખોલો\", \"પરમિશન હટાવો\"\n• हिन्दी: \"Laprri Hindi me bolo\", \"WhatsApp खोलो\", \"परमिशन हटा दो\"\n• English: \"Laprri speak in English\", \"Open WhatsApp\", \"Remove permission\"",
                                color = Color(0xFF94A3B8),
                                fontSize = 10.5.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }
        }

        // Files, Images & Wallpaper Manager Bottom Sheet
        if (showFileUploadSheet) {
            ModalBottomSheet(
                onDismissRequest = { showFileUploadSheet = false },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                containerColor = Color(0xFF18181B)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .padding(bottom = 32.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Media & Files Manager",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Upload photos, wallpapers, voice clips & documents",
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp
                            )
                        }
                        IconButton(onClick = { showFileUploadSheet = false }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 3 Upload Quick Action Buttons Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // 1. Photo / Wallpaper
                        Surface(
                            color = Color(0xFF0F766E),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { imagePickerLauncher.launch("image/*") }
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AddPhotoAlternate,
                                    contentDescription = "Upload Photo",
                                    tint = Color(0xFF5EEAD4),
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Photo/Wallpaper",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Set BG",
                                    color = Color(0xFF99F6E4),
                                    fontSize = 9.5.sp
                                )
                            }
                        }

                        // 2. Audio Voice Clip
                        Surface(
                            color = Color(0xFF1E3A8A),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { audioPickerLauncher.launch("audio/*") }
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Audiotrack,
                                    contentDescription = "Upload Audio",
                                    tint = Color(0xFF93C5FD),
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Voice Audio",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Custom voice",
                                    color = Color(0xFFBFDBFE),
                                    fontSize = 9.5.sp
                                )
                            }
                        }

                        // 3. Generic Document / File
                        Surface(
                            color = Color(0xFF374151),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { filePickerLauncher.launch("*/*") }
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CloudUpload,
                                    contentDescription = "Upload File",
                                    tint = Color(0xFFE5E7EB),
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Any File",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Doc / Media",
                                    color = Color(0xFFD1D5DB),
                                    fontSize = 9.5.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Active Wallpaper Status Card
                    if (customWallpaperPath != null) {
                        Surface(
                            color = Color(0xFF134E4A),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Wallpaper,
                                        contentDescription = "Active Wallpaper",
                                        tint = Color(0xFF2DD4BF),
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "Custom Wallpaper Active",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "Floating 3D character spins on top",
                                            color = Color(0xFF99F6E4),
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                                OutlinedButton(
                                    onClick = { voiceManager.removeCustomWallpaper() },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFCA5A5)),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("Reset Pitch Black", fontSize = 10.sp)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    // Uploaded Files List Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Stored Media & Uploads (${uploadedFiles.size})",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        IconButton(
                            onClick = { voiceManager.loadUploadedFiles() },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh uploads",
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (uploadedFiles.isEmpty()) {
                        Surface(
                            color = Color(0xFF27272A),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FolderOpen,
                                    contentDescription = "Empty",
                                    tint = Color(0xFF71717A),
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "No files uploaded yet",
                                    color = Color(0xFFE4E4E7),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "Tap Photo, Audio, or File above to add your own wallpaper, audio, or docs.",
                                    color = Color(0xFFA1A1AA),
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp),
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 240.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(uploadedFiles, key = { it.id }) { item ->
                                Surface(
                                    color = Color(0xFF27272A),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = when (item.fileType) {
                                                UploadedFileType.IMAGE -> Icons.Default.Image
                                                UploadedFileType.AUDIO -> Icons.Default.Audiotrack
                                                UploadedFileType.DOCUMENT -> Icons.Default.Description
                                                else -> Icons.Default.InsertDriveFile
                                            },
                                            contentDescription = item.fileType.name,
                                            tint = when (item.fileType) {
                                                UploadedFileType.IMAGE -> Color(0xFF2DD4BF)
                                                UploadedFileType.AUDIO -> Color(0xFF60A5FA)
                                                else -> Color(0xFFFBBF24)
                                            },
                                            modifier = Modifier.size(24.dp)
                                        )

                                        Spacer(modifier = Modifier.width(10.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = item.name,
                                                color = Color.White,
                                                fontSize = 12.5.sp,
                                                fontWeight = FontWeight.Medium,
                                                maxLines = 1
                                            )
                                            Text(
                                                text = "${item.formattedSize} • ${item.fileType.name.lowercase().replaceFirstChar { it.uppercase() }}",
                                                color = Color(0xFF94A3B8),
                                                fontSize = 10.sp
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(6.dp))

                                        // Action depending on type
                                        if (item.fileType == UploadedFileType.IMAGE) {
                                            IconButton(
                                                onClick = { voiceManager.setCustomWallpaper(item.path) },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Wallpaper,
                                                    contentDescription = "Set as wallpaper",
                                                    tint = Color(0xFF2DD4BF),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        } else if (item.fileType == UploadedFileType.AUDIO) {
                                            IconButton(
                                                onClick = { voiceManager.playUploadedAudio(item) },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.PlayArrow,
                                                    contentDescription = "Play voice audio",
                                                    tint = Color(0xFF60A5FA),
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                        }

                                        // Delete Button
                                        IconButton(
                                            onClick = { voiceManager.deleteUploadedFile(item) },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Delete file",
                                                tint = Color(0xFFEF4444),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Laprri Chat & Voice Dialogue Modal Bottom Sheet
        if (showChatSheet) {
            val listState = rememberLazyListState()
            LaunchedEffect(chatMessages.size) {
                if (chatMessages.isNotEmpty()) {
                    listState.animateScrollToItem(chatMessages.size - 1)
                }
            }

            ModalBottomSheet(
                onDismissRequest = { showChatSheet = false },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                containerColor = Color(0xFF18181B)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .padding(bottom = 28.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF0F766E))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Chat,
                                    contentDescription = "Chat",
                                    tint = Color(0xFF5EEAD4),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Laprri Chat & Commands",
                                    color = Color.White,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = when (currentLanguage) {
                                        LaprriLanguage.GUJARATI -> "લપરી આસિસ્ટન્ટ ચેટ (બોલો અથવા લખો)"
                                        LaprriLanguage.HINDI -> "लपरी असिस्टेंट चैट (बोलें या लिखें)"
                                        LaprriLanguage.ENGLISH -> "Type or Speak any query or command"
                                    },
                                    color = Color(0xFF2DD4BF),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Row {
                            IconButton(onClick = { voiceManager.clearChatHistory() }) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Clear Chat History",
                                    tint = Color(0xFF94A3B8),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            IconButton(onClick = { showChatSheet = false }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close",
                                    tint = Color.White
                                )
                            }
                        }
                    }

                    HorizontalDivider(
                        color = Color(0xFF27272A),
                        modifier = Modifier.padding(vertical = 10.dp)
                    )

                    // Quick Command Chips
                    Text(
                        text = "Quick Commands / ઝડપી આદેશો / त्वरित कमांड:",
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val chips = listOf(
                            "WhatsApp खोलो",
                            "YouTube चलाओ",
                            "Phone Dialer",
                            "Time क्या है?",
                            "Joke सुनाओ",
                            "Who are you?",
                            "કૉલ કરો",
                            "Help"
                        )
                        items(chips) { chip ->
                            Surface(
                                color = Color(0xFF27272A),
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.dp, Color(0x332DD4BF)),
                                modifier = Modifier.clickable {
                                    voiceManager.sendTextMessage(chip)
                                }
                            ) {
                                Text(
                                    text = chip,
                                    color = Color(0xFF5EEAD4),
                                    fontSize = 11.5.sp,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Chat messages list
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                            .heightIn(min = 160.dp, max = 320.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(chatMessages) { message ->
                            ChatMessageBubble(message = message)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Input Row inside Chat Sheet
                    Surface(
                        color = Color(0xFF27272A),
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, Color(0x442DD4BF)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { voiceManager.forceListenNow() },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Speak",
                                    tint = if (isListening) Color(0xFF34D399) else Color(0xFF2DD4BF),
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            BasicTextField(
                                value = chatInputText,
                                onValueChange = { chatInputText = it },
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 8.dp, vertical = 8.dp)
                                    .testTag("sheet_chat_input"),
                                textStyle = TextStyle(
                                    color = Color.White,
                                    fontSize = 13.5.sp
                                ),
                                cursorBrush = SolidColor(Color(0xFF2DD4BF)),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                keyboardActions = KeyboardActions(
                                    onSend = {
                                        if (chatInputText.isNotBlank()) {
                                            voiceManager.sendTextMessage(chatInputText)
                                            chatInputText = ""
                                        }
                                    }
                                ),
                                decorationBox = { innerTextField ->
                                    if (chatInputText.isEmpty()) {
                                        Text(
                                            text = when (currentLanguage) {
                                                LaprriLanguage.GUJARATI -> "અહીં લખીને પૂછો અથવા આદેશ આપો..."
                                                LaprriLanguage.HINDI -> "यहाँ लिखकर पूछें या कमांड दें..."
                                                LaprriLanguage.ENGLISH -> "Type command or question..."
                                            },
                                            color = Color(0xFF71717A),
                                            fontSize = 12.5.sp
                                        )
                                    }
                                    innerTextField()
                                }
                            )

                            IconButton(
                                onClick = {
                                    if (chatInputText.isNotBlank()) {
                                        voiceManager.sendTextMessage(chatInputText)
                                        chatInputText = ""
                                    }
                                },
                                enabled = chatInputText.isNotBlank(),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Send,
                                    contentDescription = "Send",
                                    tint = if (chatInputText.isNotBlank()) Color(0xFF2DD4BF) else Color(0xFF52525B),
                                    modifier = Modifier.size(19.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

fun formatFileSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val kb = bytes / 1024.0
    if (kb < 1024) return "%.1f KB".format(kb)
    val mb = kb / 1024.0
    return "%.1f MB".format(mb)
}

@Composable
fun AppPermissionRowItem(
    app: AppInfo,
    isMasterEnabled: Boolean,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 7.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Apps,
                contentDescription = app.appName,
                tint = if (app.isAllowed && isMasterEnabled) Color(0xFF2DD4BF) else Color(0xFF71717A),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = app.appName,
                    color = if (isMasterEnabled) Color.White else Color(0xFF71717A),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = if (app.isAllowed) "Allowed (Voice launch active)" else "Permission needed",
                    color = if (app.isAllowed) Color(0xFF34D399) else Color(0xFF94A3B8),
                    fontSize = 10.sp
                )
            }
        }
        Switch(
            checked = app.isAllowed,
            enabled = isMasterEnabled,
            onCheckedChange = { onToggle() },
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF0D9488)
            )
        )
    }
}

@Composable
fun ChatMessageBubble(message: ChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!message.isUser) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF0F766E))
            ) {
                Text(
                    text = "L",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Surface(
            color = if (message.isUser) Color(0xFF0F766E) else Color(0xFF27272A),
            shape = RoundedCornerShape(
                topStart = 14.dp,
                topEnd = 14.dp,
                bottomStart = if (message.isUser) 14.dp else 4.dp,
                bottomEnd = if (message.isUser) 4.dp else 14.dp
            ),
            border = if (!message.isUser) BorderStroke(1.dp, Color(0x332DD4BF)) else null,
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                Text(
                    text = message.text,
                    color = Color.White,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            }
        }
    }
}
