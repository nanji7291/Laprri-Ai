package com.example.util

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHeadset
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.content.ContextCompat
import com.example.model.AppInfo
import com.example.model.ChatMessage
import com.example.model.LaprriLanguage
import com.example.model.UploadedFileItem
import com.example.model.UploadedFileType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

/**
 * LaprriVoiceManager:
 * - Hands-free continuous wake-word & dynamic Phone App Voice Launcher.
 * - Supports 3 Languages: Gujarati (ગુજરાતી), Hindi (हिन्दी), English.
 * - Opens ANY installed app on user's phone via voice.
 * - If permission is NOT granted, Laprri asks in selected language:
 *     - Gujarati: "સર, {App} ની પરમિશન મારી પાસે નથી. શું હું આ એપની પરમિશન આપી દઉં?"
 *     - Hindi: "सर, {App} की परमिशन मेरे पास नहीं है। क्या मैं इसकी परमिशन अलाउ कर दूँ?"
 *     - English: "Sir, I don't have permission for {App}. Should I grant permission for it?"
 * - Voice commands to Grant & Revoke permissions anytime.
 * - Voice and UI Language switching anytime.
 */
class LaprriVoiceManager(private val context: Context) : TextToSpeech.OnInitListener {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val packageManager: PackageManager = context.packageManager
    private val sharedPreferences: SharedPreferences = context.getSharedPreferences("laprri_app_permissions", Context.MODE_PRIVATE)

    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false
    private var mediaPlayer: MediaPlayer? = null
    private var speechRecognizer: SpeechRecognizer? = null

    private var bluetoothHeadset: BluetoothHeadset? = null
    private var bluetoothAdapter: BluetoothAdapter? = try {
        BluetoothAdapter.getDefaultAdapter()
    } catch (_: Exception) {
        null
    }

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isBluetoothConnected = MutableStateFlow(false)
    val isBluetoothConnected: StateFlow<Boolean> = _isBluetoothConnected.asStateFlow()

    private val _bluetoothDeviceName = MutableStateFlow<String?>(null)
    val bluetoothDeviceName: StateFlow<String?> = _bluetoothDeviceName.asStateFlow()

    private val _lastDetectedWakeWord = MutableStateFlow<String?>(null)
    val lastDetectedWakeWord: StateFlow<String?> = _lastDetectedWakeWord.asStateFlow()

    // 3 Languages Support: Gujarati, Hindi, English
    private val _currentLanguage = MutableStateFlow(
        LaprriLanguage.fromCode(sharedPreferences.getString("laprri_selected_language", "hi") ?: "hi")
    )
    val currentLanguage: StateFlow<LaprriLanguage> = _currentLanguage.asStateFlow()

    private val _currentDialogue = MutableStateFlow("✨ Laprri is listening... Speak any app name to open ✨")
    val currentDialogue: StateFlow<String> = _currentDialogue.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                text = "नमस्ते! मैं लपरी (Laprri) हूँ। आप बोलकर या यहाँ लिखकर कोई भी ऐप खोलने, कॉल करने या सवाल पूछने को कह सकते हैं।",
                isUser = false
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isVoiceEnabled = MutableStateFlow(true)
    val isVoiceEnabled: StateFlow<Boolean> = _isVoiceEnabled.asStateFlow()

    // Master Phone Access Switch
    private val _isPhoneAccessEnabled = MutableStateFlow(true)
    val isPhoneAccessEnabled: StateFlow<Boolean> = _isPhoneAccessEnabled.asStateFlow()

    // Real-time microphone audio volume level (0f to 10f+) for visual sound wave meter
    private val _rmsVolume = MutableStateFlow(0f)
    val rmsVolume: StateFlow<Float> = _rmsVolume.asStateFlow()

    // Custom Wallpaper Photo path
    private val _customWallpaperPath = MutableStateFlow<String?>(
        sharedPreferences.getString("custom_wallpaper_path", null)
    )
    val customWallpaperPath: StateFlow<String?> = _customWallpaperPath.asStateFlow()

    // Uploaded Files & Images list
    private val _uploadedFiles = MutableStateFlow<List<UploadedFileItem>>(emptyList())
    val uploadedFiles: StateFlow<List<UploadedFileItem>> = _uploadedFiles.asStateFlow()

    // State for App currently waiting for user's voice permission confirmation
    private val _pendingPermissionApp = MutableStateFlow<AppInfo?>(null)
    val pendingPermissionApp: StateFlow<AppInfo?> = _pendingPermissionApp.asStateFlow()

    // List of installed applications on phone
    private val _installedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val installedApps: StateFlow<List<AppInfo>> = _installedApps.asStateFlow()

    private val _hasCustomAudio = MutableStateFlow(false)
    val hasCustomAudio: StateFlow<Boolean> = _hasCustomAudio.asStateFlow()

    private val customAudioFiles = mutableListOf<File>()

    private var isRecognitionActive = false
    private var hasAudioPermission = false
    private var isReceiverRegistered = false

    // Wake words variants across Gujarati, Hindi, English
    private val wakeWordKeywords = listOf(
        "laprri", "lapri", "lapree", "lappri", "lepree", "lepri",
        "lapari", "lapuri", "lapary", "lapry", "lopri", "lopree",
        "lupri", "lafri", "labri", "lovery", "loverly", "libri", "lipri",
        "લપરી", "લપ્રી", "લફરી", "લાપરી", "લપરી", "લેપ્રી",
        "लपरी", "लप्री", "लापरी", "लैपरी", "लफ्री", "लपारी", "लपरी", "लपरी जी", "लपरीजी"
    )

    private val generalWakeResponsesGujarati = listOf(
        "હા સર, બોલો! લપરી અહીં છે, કઈ એપ ખોલવી છે?",
        "જી સર! લપરી તૈયાર છે, બોલો શું ઓર્ડર છે?",
        "તમે બોલાવ્યા અને લપરી હાજર! WhatsApp, YouTube, Gallery કે કોઈ પણ એપ બોલો.",
        "હેય! હું લાઈવ સાંભળી રહી છું, બોલો કઈ એપ ચલાવવી છે?",
        "હાજી સર! લપરી તમારા આદેશ માટે તૈયાર છે!"
    )

    private val generalWakeResponsesHindi = listOf(
        "हाँ सर, बोलिए! लपरी यहाँ है, कौनसी ऐप ओपन करनी है?",
        "जी सर! लपरी तैयार है, बोलिए क्या आर्डर है?",
        "आपने बुलाया और लपरी हाजिर! WhatsApp, YouTube, Gallery या कोई भी ऐप खोलने को बोलिए।",
        "हेय! मैं लाइव सुन रही हूँ, बोलिए किसे कॉल या कौनसी ऐप चलानी है?",
        "हाँजी सर! लपरी आपके कमांड्स के लिए तैयार है!"
    )

    private val generalWakeResponsesEnglish = listOf(
        "Yes Sir! Laprri is here, which app would you like to open?",
        "Laprri is ready! Tell me your command, Sir.",
        "At your service! Say WhatsApp, YouTube, Gallery or any app to launch.",
        "Hey! I'm listening live, tell me which app you want to open.",
        "Ready and listening, Sir! What's next?"
    )

    private var lastResponseIndex = -1

    private val bluetoothReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            val action = intent?.action ?: return
            when (action) {
                BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED -> {
                    val state = intent.getIntExtra(BluetoothProfile.EXTRA_STATE, BluetoothProfile.STATE_DISCONNECTED)
                    if (state == BluetoothProfile.STATE_CONNECTED) {
                        checkBluetoothAudioRouting()
                    } else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                        onBluetoothDisconnected()
                    }
                }
                AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED -> {
                    val state = intent.getIntExtra(AudioManager.EXTRA_SCO_AUDIO_STATE, AudioManager.SCO_AUDIO_STATE_DISCONNECTED)
                    if (state == AudioManager.SCO_AUDIO_STATE_CONNECTED) {
                        _isBluetoothConnected.value = true
                    } else if (state == AudioManager.SCO_AUDIO_STATE_DISCONNECTED) {
                        if (!isBluetoothScoHeadsetConnected()) {
                            _isBluetoothConnected.value = false
                            _bluetoothDeviceName.value = null
                        }
                    }
                }
                BluetoothDevice.ACTION_ACL_CONNECTED -> {
                    checkBluetoothAudioRouting()
                }
                BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                    onBluetoothDisconnected()
                }
            }
        }
    }

    private val profileListener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
            if (profile == BluetoothProfile.HEADSET) {
                bluetoothHeadset = proxy as? BluetoothHeadset
                checkBluetoothAudioRouting()
            }
        }

        override fun onServiceDisconnected(profile: Int) {
            if (profile == BluetoothProfile.HEADSET) {
                bluetoothHeadset = null
                onBluetoothDisconnected()
            }
        }
    }

    init {
        tts = TextToSpeech(context.applicationContext, this)
        loadCustomAudioClips()
        loadInstalledApps()
        loadUploadedFiles()
        setupBluetoothReceiver()
        initBluetoothProfile()
    }

    fun setLanguage(language: LaprriLanguage, notifyUser: Boolean = true) {
        _currentLanguage.value = language
        sharedPreferences.edit().putString("laprri_selected_language", language.code).apply()
        setupVoiceEngine()

        if (notifyUser) {
            when (language) {
                LaprriLanguage.GUJARATI -> {
                    _currentDialogue.value = "✨ ગુજરાતી ભાષા પસંદ કરી છે ✨"
                    speakText("નમસ્તે! લપરી હવે તમારી સાથે ગુજરાતીમાં વાત કરશે.")
                }
                LaprriLanguage.HINDI -> {
                    _currentDialogue.value = "✨ हिन्दी भाषा चुनी गई है ✨"
                    speakText("नमस्ते! लपरी अब आपसे हिन्दी में बात करेगी।")
                }
                LaprriLanguage.ENGLISH -> {
                    _currentDialogue.value = "✨ English Language Selected ✨"
                    speakText("Hello! Laprri will now speak with you in English.")
                }
            }
        }
    }

    /**
     * Load all launchable apps from phone and sync with saved permission states
     */
    fun loadInstalledApps() {
        try {
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = packageManager.queryIntentActivities(mainIntent, 0)
            val allowedSet = getSavedAllowedPackages()

            val apps = resolveInfos.mapNotNull { resolveInfo ->
                val pkgName = resolveInfo.activityInfo.packageName
                if (pkgName == context.packageName) return@mapNotNull null

                val appName = resolveInfo.loadLabel(packageManager).toString()
                AppInfo(
                    appName = appName,
                    packageName = pkgName,
                    isAllowed = allowedSet.contains(pkgName)
                )
            }.sortedBy { it.appName.lowercase() }

            _installedApps.value = apps
        } catch (_: Exception) {}
    }

    private fun getSavedAllowedPackages(): Set<String> {
        return sharedPreferences.getStringSet("allowed_packages", emptySet()) ?: emptySet()
    }

    private fun saveAllowedPackages(packages: Set<String>) {
        sharedPreferences.edit().putStringSet("allowed_packages", packages).apply()
        loadInstalledApps()
    }

    fun isAppAllowed(packageName: String): Boolean {
        return getSavedAllowedPackages().contains(packageName)
    }

    fun grantPermissionForApp(app: AppInfo) {
        val currentSet = getSavedAllowedPackages().toMutableSet()
        currentSet.add(app.packageName)
        saveAllowedPackages(currentSet)
    }

    fun revokePermissionForApp(app: AppInfo) {
        val currentSet = getSavedAllowedPackages().toMutableSet()
        currentSet.remove(app.packageName)
        saveAllowedPackages(currentSet)
    }

    fun grantAllPermissions() {
        val allPkgs = _installedApps.value.map { it.packageName }.toSet()
        saveAllowedPackages(allPkgs)
        when (_currentLanguage.value) {
            LaprriLanguage.GUJARATI -> speakText("સર, બધી એપ્સને પરમિશન આપી દીધી છે.")
            LaprriLanguage.HINDI -> speakText("सर, सभी ऐप्स को परमिशन अलाउ कर दी गई है।")
            LaprriLanguage.ENGLISH -> speakText("Sir, permissions for all applications have been granted.")
        }
    }

    fun revokeAllPermissions() {
        saveAllowedPackages(emptySet())
        when (_currentLanguage.value) {
            LaprriLanguage.GUJARATI -> speakText("સર, બધી એપ્સની પરમિશન હટાવી દીધી છે.")
            LaprriLanguage.HINDI -> speakText("सर, सभी ऐप्स की परमिशन हटा दी गई है।")
            LaprriLanguage.ENGLISH -> speakText("Sir, permissions for all applications have been revoked.")
        }
    }

    fun toggleAppPermission(app: AppInfo) {
        if (app.isAllowed) {
            revokePermissionForApp(app)
            when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> speakText("${app.appName} ની પરમિશન હટાવી દીધી છે.")
                LaprriLanguage.HINDI -> speakText("${app.appName} की परमिशन हटा दी गई है।")
                LaprriLanguage.ENGLISH -> speakText("Permission removed for ${app.appName}.")
            }
        } else {
            grantPermissionForApp(app)
            when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> speakText("${app.appName} ને પરમિશન આપી દીધી છે.")
                LaprriLanguage.HINDI -> speakText("${app.appName} को परमिशन दे दी गई है।")
                LaprriLanguage.ENGLISH -> speakText("Permission granted for ${app.appName}.")
            }
        }
    }

    fun setPhoneAccessEnabled(enabled: Boolean) {
        _isPhoneAccessEnabled.value = enabled
        if (enabled) {
            when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> speakText("ફોન એક્સેસ ચાલુ કરી દીધું છે. હવે તમે બોલીને કોઈપણ એપ ખોલી શકો છો.")
                LaprriLanguage.HINDI -> speakText("फ़ोन एक्सेस चालू कर दिया गया है। अब आप वॉइस से कोई भी ऐप ओपन कर सकते हैं।")
                LaprriLanguage.ENGLISH -> speakText("Phone voice access is now enabled. You can launch any app by voice.")
            }
        } else {
            when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> speakText("ફોન એક્સેસ બંધ કરી દીધું છે.")
                LaprriLanguage.HINDI -> speakText("फ़ोन एक्सेस बंद कर दिया गया है।")
                LaprriLanguage.ENGLISH -> speakText("Phone voice access has been disabled.")
            }
        }
    }

    private fun setupBluetoothReceiver() {
        try {
            val filter = IntentFilter().apply {
                addAction(BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED)
                addAction(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED)
                addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
                addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
                addAction(Intent.ACTION_HEADSET_PLUG)
            }
            context.registerReceiver(bluetoothReceiver, filter)
            isReceiverRegistered = true
        } catch (_: Exception) {}
    }

    private fun initBluetoothProfile() {
        try {
            bluetoothAdapter?.getProfileProxy(context, profileListener, BluetoothProfile.HEADSET)
        } catch (_: Exception) {}
    }

    fun checkBluetoothAudioRouting() {
        mainHandler.post {
            try {
                // Ensure audio mode is ALWAYS MODE_NORMAL:
                // MODE_IN_COMMUNICATION triggers the device proximity sensor which turns off the screen (black screen bug)!
                // Keeping MODE_NORMAL ensures the screen NEVER turns black and microphone input works smoothly.
                try {
                    audioManager.mode = AudioManager.MODE_NORMAL
                } catch (_: Exception) {}

                var isBt = false
                var devName: String? = null

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val commDevices = audioManager.availableCommunicationDevices
                    val btCommDevice = commDevices.firstOrNull { dev ->
                        dev.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                        dev.type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                        dev.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                        dev.type == AudioDeviceInfo.TYPE_HEARING_AID
                    }

                    if (btCommDevice != null) {
                        isBt = true
                        devName = btCommDevice.productName?.toString() ?: "Bluetooth Device"
                    }
                }

                if (!isBt) {
                    val hasScoHeadset = isBluetoothScoHeadsetConnected()
                    if (hasScoHeadset) {
                        isBt = true
                        devName = _bluetoothDeviceName.value ?: "Bluetooth Headset"
                    }
                }

                _isBluetoothConnected.value = isBt
                _bluetoothDeviceName.value = devName ?: if (isBt) "Bluetooth Device" else null
            } catch (_: Exception) {}
        }
    }

    private fun isBluetoothScoHeadsetConnected(): Boolean {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {
                    return false
                }
            }
            val devices = bluetoothHeadset?.connectedDevices
            if (!devices.isNullOrEmpty()) {
                _bluetoothDeviceName.value = devices.firstOrNull()?.name ?: "Bluetooth Headset"
                return true
            }
            return false
        } catch (_: Exception) {
            return false
        }
    }

    private fun onBluetoothDisconnected() {
        mainHandler.post {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    audioManager.clearCommunicationDevice()
                }
                audioManager.mode = AudioManager.MODE_NORMAL
            } catch (_: Exception) {}
            _isBluetoothConnected.value = false
            _bluetoothDeviceName.value = null
        }
    }

    private fun loadCustomAudioClips() {
        try {
            val audioDir = File(context.filesDir, "custom_voices")
            if (audioDir.exists()) {
                val files = audioDir.listFiles { file ->
                    file.extension.lowercase() in listOf("mp3", "wav", "m4a", "ogg", "aac")
                }
                if (!files.isNullOrEmpty()) {
                    customAudioFiles.clear()
                    customAudioFiles.addAll(files)
                    _hasCustomAudio.value = true
                }
            }
        } catch (_: Exception) {}
    }

    fun setPermissionGranted(granted: Boolean) {
        hasAudioPermission = granted
        if (granted) {
            checkBluetoothAudioRouting()
            startContinuousListening()
        }
    }

    fun forceListenNow() {
        stop()
        safeResetRecognizer()
        mainHandler.removeCallbacksAndMessages(null)
        _currentDialogue.value = when (_currentLanguage.value) {
            LaprriLanguage.GUJARATI -> "🎙️ સાંભળી રહી છું... બોલો સર!"
            LaprriLanguage.HINDI -> "🎙️ सुन रही हूँ... बोलिए सर!"
            LaprriLanguage.ENGLISH -> "🎙️ Listening... Speak now Sir!"
        }
        startContinuousListening()
    }

    fun safeResetRecognizer() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        speechRecognizer = null
        isRecognitionActive = false
        _rmsVolume.value = 0f
    }

    fun startContinuousListening() {
        if (!hasAudioPermission) return
        mainHandler.post {
            try {
                if (_isSpeaking.value) return@post

                checkBluetoothAudioRouting()

                // Cancel previous session safely if stuck
                if (speechRecognizer != null && isRecognitionActive) {
                    try {
                        speechRecognizer?.cancel()
                    } catch (_: Exception) {}
                    isRecognitionActive = false
                }

                if (speechRecognizer == null) {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                        setRecognitionListener(createRecognitionListener())
                    }
                }

                val langTag = _currentLanguage.value.localeTag
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, langTag)
                    putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                    putExtra("android.speech.extra.DICTATION_MODE", true)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                }
                speechRecognizer?.startListening(intent)
                _isListening.value = true
                isRecognitionActive = true
            } catch (_: Exception) {
                _isListening.value = false
                isRecognitionActive = false
                safeResetRecognizer()
                restartListeningWithDelay(1500)
            }
        }
    }

    private fun stopListening() {
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
                speechRecognizer?.cancel()
            } catch (_: Exception) {}
            _isListening.value = false
            isRecognitionActive = false
            _rmsVolume.value = 0f
        }
    }

    private fun restartListeningWithDelay(delayMs: Long = 500) {
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.postDelayed({
            if (hasAudioPermission && !_isSpeaking.value) {
                startContinuousListening()
            }
        }, delayMs)
    }

    private fun createRecognitionListener(): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _isListening.value = true
                isRecognitionActive = true
            }

            override fun onBeginningOfSpeech() {
                _isListening.value = true
            }

            override fun onRmsChanged(rmsdB: Float) {
                if (rmsdB > 0f) {
                    _rmsVolume.value = rmsdB
                }
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                _isListening.value = false
            }

            override fun onError(error: Int) {
                _isListening.value = false
                isRecognitionActive = false
                _rmsVolume.value = 0f

                // In case of busy/client/audio errors, reset recognizer completely
                if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                    error == SpeechRecognizer.ERROR_CLIENT ||
                    error == 3 /* ERROR_AUDIO */) {
                    safeResetRecognizer()
                }

                val delay = if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    300L
                } else {
                    1000L
                }
                restartListeningWithDelay(delay)
            }

            override fun onResults(results: Bundle?) {
                _rmsVolume.value = 0f
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                checkMatchesForWakeWordAndCommands(matches)
                restartListeningWithDelay(400)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                checkMatchesForWakeWordAndCommands(partialResults = matches, isPartial = true)
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    private fun checkMatchesForWakeWordAndCommands(matches: ArrayList<String>? = null, partialResults: ArrayList<String>? = null, isPartial: Boolean = false) {
        val list = matches ?: partialResults ?: return
        if (list.isEmpty() || _isSpeaking.value) return

        for (phrase in list) {
            val lower = phrase.lowercase().trim()
            if (lower.isBlank()) continue

            val containsWakeWord = wakeWordKeywords.any { kw -> lower.contains(kw) }
            val detectedApp = findAppInQuery(lower)
            val isQuestionOrChat = lower.contains("time") || lower.contains("date") || lower.contains("tarikh") ||
                    lower.contains("joke") || lower.contains("chutkula") || lower.contains("kaise ho") ||
                    lower.contains("kem cho") || lower.contains("who are you") || lower.contains("kaun ho") ||
                    lower.contains("namaste") || lower.contains("hello") || lower.contains("hi") ||
                    lower.contains("help") || lower.contains("madad") || lower.contains("shayari") ||
                    lower.contains("તારીખ") || lower.contains("જોક") || lower.contains("શાયરી") ||
                    lower.contains("કેમ છો") || lower.contains("કોણ છો") || lower.contains("કેટલા વાગ્યા")

            // Any recognized action, app, permission answer, language switch, chat question, or wake word:
            if (_pendingPermissionApp.value != null ||
                containsWakeWord ||
                detectedApp != null ||
                isQuestionOrChat ||
                lower.contains("kholo") || lower.contains("open") || lower.contains("chalao") || lower.contains("chalu") ||
                lower.contains("ખોલો") || lower.contains("ચાલુ") || lower.contains("બતાવો") ||
                lower.contains("call") || lower.contains("dial") || lower.contains("message") || lower.contains("sms") ||
                lower.contains("band") || lower.contains("close") || lower.contains("stop") ||
                lower.contains("permission") || lower.contains("પરમિશન") || lower.contains("access") ||
                lower.contains("gujarati") || lower.contains("ગુજરાતી") ||
                lower.contains("hindi") || lower.contains("हिन्दी") || lower.contains("हिंदी") ||
                lower.contains("english") || lower.contains("ઇંગ્લિશ")) {

                _lastDetectedWakeWord.value = "Heard: \"$lower\""
                processVoiceCommand(lower)
                break
            }
        }
    }

    fun sendTextMessage(input: String) {
        val trimmed = input.trim()
        if (trimmed.isBlank()) return
        addChatMessage(trimmed, isUser = true)
        processCommand(trimmed, fromVoice = false)
    }

    fun addChatMessage(text: String, isUser: Boolean) {
        val msg = ChatMessage(text = text, isUser = isUser)
        _chatMessages.value = _chatMessages.value + msg
    }

    fun clearChatHistory() {
        _chatMessages.value = emptyList()
    }

    fun deliverResponse(dialogue: String, spokenText: String = dialogue) {
        _currentDialogue.value = dialogue
        addChatMessage(dialogue, isUser = false)
        if (_isVoiceEnabled.value) {
            speakText(spokenText)
        }
    }

    private fun processVoiceCommand(spokenText: String) {
        val trimmed = spokenText.trim()
        if (trimmed.isNotBlank()) {
            addChatMessage(trimmed, isUser = true)
        }
        processCommand(trimmed, fromVoice = true)
    }

    /**
     * Main Multilingual Voice & Chat Command Processor:
     * - Spoken voice commands or typed chat messages
     * - Conversational queries & questions (Time, Date, Joke, Shayari, About, Help)
     * - Language switching ("Laprri Gujarati ma bolo", "Laprri Hindi me bolo", "Laprri Speak English")
     * - Pending Permission confirmation (Yes/No in Gujarati, Hindi, English)
     * - Revoke permission for any app
     * - Grant permission for any app
     * - Open any installed app
     * - Calling, SMS, Location, Mail, Close, Master Access
     */
    fun processCommand(inputText: String, fromVoice: Boolean = false) {
        val text = inputText.lowercase().trim()

        // 1. Language Switching Commands
        if (text.contains("gujarati") || text.contains("ગુજરાતી") || text.contains("gujrati")) {
            if (text.contains("bolo") || text.contains("bhasha") || text.contains("bhasa") || text.contains("language") ||
                text.contains("switch") || text.contains("change") || text.contains("karo") || text.contains("vaat karo")) {
                if (fromVoice) stopListening()
                setLanguage(LaprriLanguage.GUJARATI, notifyUser = true)
                addChatMessage("ગુજરાતી ભાષા સેટ કરી દીધી છે.", isUser = false)
                return
            }
        }

        if (text.contains("hindi") || text.contains("हिन्दी") || text.contains("हिंदी")) {
            if (text.contains("bolo") || text.contains("bhasha") || text.contains("bhasa") || text.contains("language") ||
                text.contains("switch") || text.contains("change") || text.contains("karo") || text.contains("baat karo")) {
                if (fromVoice) stopListening()
                setLanguage(LaprriLanguage.HINDI, notifyUser = true)
                addChatMessage("हिन्दी भाषा सेट कर दी गई है।", isUser = false)
                return
            }
        }

        if (text.contains("english") || text.contains("अंग्रेजी") || text.contains("ઇંગ્લિશ") || text.contains("inglish")) {
            if (text.contains("speak") || text.contains("bolo") || text.contains("talk") || text.contains("language") ||
                text.contains("switch") || text.contains("change") || text.contains("karo")) {
                if (fromVoice) stopListening()
                setLanguage(LaprriLanguage.ENGLISH, notifyUser = true)
                addChatMessage("Language changed to English.", isUser = false)
                return
            }
        }

        // 2. Check if we are waiting for user's permission response for a pending app
        val pendingApp = _pendingPermissionApp.value
        if (pendingApp != null) {
            if (isAffirmative(text)) {
                if (fromVoice) stopListening()
                grantPermissionForApp(pendingApp)
                _pendingPermissionApp.value = null
                val openMsg = when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> "જી સર, ${pendingApp.appName} ને પરમિશન આપી દીધી છે. હવે ઓપન કરી રહી છું..."
                    LaprriLanguage.HINDI -> "जी सर, ${pendingApp.appName} को परमिशन दे दी गई है। अब ओपन कर रही हूँ..."
                    LaprriLanguage.ENGLISH -> "Yes Sir, permission granted for ${pendingApp.appName}. Opening now..."
                }
                deliverResponse("✅ Permission granted for ${pendingApp.appName}. Opening now...", openMsg)
                mainHandler.postDelayed({
                    launchAppByPackage(pendingApp.packageName, pendingApp.appName)
                }, 1000)
                return
            } else if (isNegative(text)) {
                if (fromVoice) stopListening()
                _pendingPermissionApp.value = null
                val deniedMsg = when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> "ઠીક છે સર, ${pendingApp.appName} ની પરમિશન નથી આપી."
                    LaprriLanguage.HINDI -> "ठीक है सर, ${pendingApp.appName} की परमिशन नहीं दी गई।"
                    LaprriLanguage.ENGLISH -> "Alright Sir, permission was denied for ${pendingApp.appName}."
                }
                deliverResponse("❌ Permission denied for ${pendingApp.appName}.", deniedMsg)
                return
            }
        }

        // 3. Phone Access Master Toggle Commands
        if (text.contains("access off") || text.contains("access band") || text.contains("permission band") ||
            text.contains("phone band karo") || text.contains("એક્સેસ બંધ") || text.contains("ફોન બંધ કરો")) {
            if (fromVoice) stopListening()
            _isPhoneAccessEnabled.value = false
            val resp = when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> "ઠીક છે, ફોન એક્સેસ બંધ કરી દીધું છે."
                LaprriLanguage.HINDI -> "ठीक है, फ़ोन एक्सेस बंद कर दिया है।"
                LaprriLanguage.ENGLISH -> "Phone voice access has been disabled."
            }
            deliverResponse("🔒 Phone access disabled.", resp)
            return
        }

        if (text.contains("access on") || text.contains("access chalu") || text.contains("permission chalu") ||
            text.contains("phone chalu karo") || text.contains("એક્સેસ ચાલુ") || text.contains("ફોન ચાલુ કરો")) {
            if (fromVoice) stopListening()
            _isPhoneAccessEnabled.value = true
            val resp = when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> "ફોન એક્સેસ ચાલુ કરી દીધું છે. તમે કોઈપણ એપનું નામ બોલીને કે લખીને તેને ખોલી શકો છો."
                LaprriLanguage.HINDI -> "फ़ोन एक्सेस चालू कर दिया है। आप किसी भी ऐप का नाम बोलकर या लिखकर उसे ओपन कर सकते हैं।"
                LaprriLanguage.ENGLISH -> "Phone access enabled. You can speak or type any app name to open it."
            }
            deliverResponse("🔓 Phone access enabled.", resp)
            return
        }

        // 4. Remove / Revoke Permission Commands
        if (text.contains("permission hata") || text.contains("permission band") || text.contains("permission remove") ||
            text.contains("remove permission") || text.contains("revoke permission") || text.contains("permission cancel") ||
            text.contains("access hata") || text.contains("access band") || text.contains("પરમિશન હટાવો") || text.contains("પરમિશન બંધ")) {
            
            if (fromVoice) stopListening()
            if (text.contains("sab") || text.contains("all") || text.contains("badhi") || text.contains("બધી")) {
                revokeAllPermissions()
                deliverResponse("🔒 All app permissions removed.", "सभी ऐप्स की परमिशन हटा दी गई है।")
                return
            }

            val targetApp = findAppInQuery(text)
            if (targetApp != null) {
                revokePermissionForApp(targetApp)
                val resp = when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> "સર, ${targetApp.appName} ની પરમિશન સફળતાપૂર્વક હટાવી દીધી છે."
                    LaprriLanguage.HINDI -> "सर, ${targetApp.appName} की परमिशन सफलतापूर्वक हटा दी गई है।"
                    LaprriLanguage.ENGLISH -> "Sir, permission for ${targetApp.appName} has been revoked successfully."
                }
                deliverResponse("🚫 Permission removed for ${targetApp.appName}.", resp)
            } else {
                val resp = when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> "સર, તમે કઈ એપની પરમિશન હટાવવા માંગો છો?"
                    LaprriLanguage.HINDI -> "सर, आप कौनसी ऐप की परमिशन हटाना चाहते हैं?"
                    LaprriLanguage.ENGLISH -> "Sir, which app's permission would you like to remove?"
                }
                deliverResponse(resp)
            }
            return
        }

        // 5. Grant Permission explicitly
        if (text.contains("permission de do") || text.contains("permission allow") || text.contains("allow permission") ||
            text.contains("permission chalu") || text.contains("permission dedo") || text.contains("પરમિશન આપો") ||
            text.contains("પરમિશન આપી દો") || text.contains("પરમિશન ચાલુ")) {
            
            if (fromVoice) stopListening()
            if (text.contains("sab") || text.contains("all") || text.contains("badhi") || text.contains("બધી")) {
                grantAllPermissions()
                deliverResponse("🔓 All app permissions granted.", "सभी ऐप्स को परमिशन दे दी गई है।")
                return
            }

            val targetApp = findAppInQuery(text)
            if (targetApp != null) {
                grantPermissionForApp(targetApp)
                val resp = when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> "સર, ${targetApp.appName} ને પરમિશન આપી દીધી છે."
                    LaprriLanguage.HINDI -> "सर, ${targetApp.appName} को परमिशन अलाउ कर दी गई है।"
                    LaprriLanguage.ENGLISH -> "Sir, permission granted for ${targetApp.appName}."
                }
                deliverResponse("✅ Permission granted for ${targetApp.appName}.", resp)
            } else {
                val resp = when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> "સર, તમે કઈ એપને પરમિશન આપવા માંગો છો?"
                    LaprriLanguage.HINDI -> "सर, आप कौनसी ऐप को परमिशन देना चाहते हैं?"
                    LaprriLanguage.ENGLISH -> "Sir, which app would you like to grant permission for?"
                }
                deliverResponse(resp)
            }
            return
        }

        // 6. Close / Back / Go Home Command
        if (text.contains("close") || text.contains("band karo") || text.contains("home") ||
            text.contains("piche jao") || text.contains("exit") || text.contains("પાછા જાઓ") ||
            text.contains("બંધ કરો") || text.contains("હોમ સ્ક્રીન")) {
            if (fromVoice) stopListening()
            val resp = when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> "ઠીક છે સર, પાછા હોમ સ્ક્રીન પર જઈ રહી છું..."
                LaprriLanguage.HINDI -> "ठीक है सर, बैक जा रही हूँ..."
                LaprriLanguage.ENGLISH -> "Going back to Home screen, Sir..."
            }
            deliverResponse("🏠 Closing to Home Screen...", resp)
            mainHandler.postDelayed({
                try {
                    val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_HOME)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(homeIntent)
                } catch (_: Exception) {}
            }, 800)
            return
        }

        // 7. Direct Built-in Commands: Calling / SMS / Location / Mail
        if (text.contains("dial") || (text.contains("call") && !text.contains("calling app")) ||
            text.contains("ફોન કરો") || text.contains("કોલ કરો") || text.contains("call lagao")) {
            handleCallCommand(text)
            return
        }

        if (text.contains("message") || text.contains("sms") || text.contains("text bhejo") ||
            text.contains("msg") || text.contains("મેસેજ") || text.contains("મેસેજ મોકલો")) {
            handleSmsCommand()
            return
        }

        if (text.contains("location") || text.contains("map") || text.contains("kahan hu") ||
            text.contains("navigation") || text.contains("rasta") || text.contains("લોકેશન") ||
            text.contains("નકશો") || text.contains("હું ક્યાં છું")) {
            handleLocationCommand()
            return
        }

        if (text.contains("email") || (text.contains("mail") && !text.contains("gmail")) || text.contains("મેઇલ")) {
            handleMailCommand()
            return
        }

        // 8. Smart Conversational Questions & Chat
        // Who are you?
        if (text.contains("kaun ho") || text.contains("who are you") || text.contains("કોણ છો") ||
            text.contains("kon cho") || text.contains("naam kya hai") || text.contains("who made you")) {
            val resp = when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> "હું લપરી (Laprri) છું, તમારી સ્માર્ટ AI અને વોઇસ આસિસ્ટન્ટ! તમે મને એપ ખોલવા, કોલ કરવા, મેસેજ મોકલવા કે કોઈ પણ સવાલ પૂછવા કહી શકો છો."
                LaprriLanguage.HINDI -> "मैं लपरी (Laprri) हूँ, आपकी स्मार्ट पर्सनल AI और वॉइस असिस्टेंट! आप मुझे बोलकर या लिखकर कोई भी ऐप खोलने, कॉल करने या सवाल पूछने को कह सकते हैं।"
                LaprriLanguage.ENGLISH -> "I am Laprri, your smart AI and voice assistant! You can speak or type to open any app, manage calls, or ask any question."
            }
            deliverResponse(resp)
            return
        }

        // How are you?
        if (text.contains("kaise ho") || text.contains("kem cho") || text.contains("how are you") || text.contains("kem chho") || text.contains("kya haal")) {
            val resp = when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> "હું એકદમ મજામાં છું! તમે કેમ છો? હું તમારી શું સેવા કરી શકું?"
                LaprriLanguage.HINDI -> "मैं बहुत अच्छी हूँ! आप कैसे हैं? बताइए मैं आपकी क्या सहायता कर सकती हूँ?"
                LaprriLanguage.ENGLISH -> "I'm doing great! How are you doing today? How can I help you?"
            }
            deliverResponse(resp)
            return
        }

        // Greetings
        if (text == "hi" || text == "hello" || text == "hey" || text.contains("namaste") || text.contains("kem cho") || text.contains("ram ram") || text.contains("good morning") || text.contains("good evening")) {
            val resp = when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> "નમસ્તે! બોલો સર, હું તમારી શું મદદ કરી શકું?"
                LaprriLanguage.HINDI -> "नमस्ते! बोलिए सर, मैं आपकी क्या सहायता कर सकती हूँ?"
                LaprriLanguage.ENGLISH -> "Hello Sir! How can I assist you today?"
            }
            deliverResponse(resp)
            return
        }

        // Time query
        if (text.contains("time") || text.contains("kitne baje") || text.contains("samay") || text.contains("કેટલા વાગ્યા") || text.contains("સમય")) {
            val timeStr = java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault()).format(java.util.Date())
            val resp = when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> "અત્યારે $timeStr વાગ્યા છે."
                LaprriLanguage.HINDI -> "अभी $timeStr हो रहे हैं।"
                LaprriLanguage.ENGLISH -> "The current time is $timeStr."
            }
            deliverResponse(resp)
            return
        }

        // Date query
        if (text.contains("date") || text.contains("tarikh") || text.contains("તારીખ") || text.contains("aaj kya hai")) {
            val dateStr = java.text.SimpleDateFormat("EEEE, dd MMMM yyyy", java.util.Locale.getDefault()).format(java.util.Date())
            val resp = when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> "આજની તારીખ $dateStr છે."
                LaprriLanguage.HINDI -> "आज की तारीख $dateStr है।"
                LaprriLanguage.ENGLISH -> "Today's date is $dateStr."
            }
            deliverResponse(resp)
            return
        }

        // Joke query
        if (text.contains("joke") || text.contains("chutkula") || text.contains("hasao") || text.contains("જોક") || text.contains("રમુજ")) {
            val jokesGujarati = listOf(
                "શિક્ષક: પૃથ્વી ગોળ કેમ છે? વિદ્યાર્થી: કારણ કે એને કોઈ ખૂણામાં બેસવું નથી ગમતું!",
                "પપ્પુ: મમ્મી, લોકો કહે છે હું વાંદરા જેવો દેખાઉં છું! મમ્મી: બેટા, ચૂપચાપ કેળું ખા, લોકોનું કામ જ બોલવાનું છે!"
            )
            val jokesHindi = listOf(
                "टीचर: बताओ न्यूटन का चौथा नियम क्या है? छात्र: सर, जब परीक्षा आती है तब दिमाग की सारी बत्ती गुल हो जाती है!",
                "पप्पू: डॉक्टर साहब, जब भी चाय पीता हूँ आँख में दर्द होता है! डॉक्टर: अगली बार चाय पीते समय कप से चम्मच निकाल लिया करो!"
            )
            val jokesEnglish = listOf(
                "Why don't scientists trust atoms? Because they make up everything!",
                "Why was the math book sad? Because it had too many problems!"
            )
            val joke = when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> jokesGujarati.random()
                LaprriLanguage.HINDI -> jokesHindi.random()
                LaprriLanguage.ENGLISH -> jokesEnglish.random()
            }
            deliverResponse(joke)
            return
        }

        // Shayari query
        if (text.contains("shayari") || text.contains("kavita") || text.contains("શાયરી")) {
            val shayari = when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> "મંઝિલ મળશે જ ભલે ભટકીને મળે, ગુમરાહ તો એ છે જે ઘરથી નીકળ્યા જ નથી!"
                LaprriLanguage.HINDI -> "मंजिलें उन्हीं को मिलती हैं जिनके सपनों में जान होती है, पंखों से कुछ नहीं होता हौसलों से उड़ान होती है!"
                LaprriLanguage.ENGLISH -> "Keep your face always toward the sunshine, and shadows will fall behind you."
            }
            deliverResponse(shayari)
            return
        }

        // Help / commands
        if (text.contains("help") || text.contains("madad") || text.contains("commands") || text.contains("kya kar sakti ho") || text.contains("શું કરી શકો")) {
            val help = when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> "તમે મને આ કહી શકો છો:\n• 'WhatsApp ખોલો' અથવા કોઈ પણ એપ\n• 'Call કરો'\n• 'Message મોકલો'\n• 'સમય કેટલો થયો'\n• 'જોક કહો' અથવા અહીં સીધું લખો!"
                LaprriLanguage.HINDI -> "आप मुझे ये कमांड दे सकते हैं:\n• 'WhatsApp खोलो' या किसी भी ऐप का नाम\n• 'Call करो' या नंबर डायल करें\n• 'Message भेजो'\n• 'Time क्या है'\n• 'Joke सुनाओ' या सीधे चैट में लिखें!"
                LaprriLanguage.ENGLISH -> "You can ask me to:\n• 'Open WhatsApp' or any installed app\n• 'Call dialer'\n• 'Send message'\n• 'What is the time'\n• 'Tell a joke' or type directly in chat!"
            }
            deliverResponse(help)
            return
        }

        // 9. General App Launcher by Voice / Text (Matches ANY app on phone!)
        val detectedApp = findAppInQuery(text)
        if (detectedApp != null) {
            if (fromVoice) stopListening()
            if (!_isPhoneAccessEnabled.value) {
                val offMsg = when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> "ફોન એક્સેસ અત્યારે બંધ છે. કૃપા કરીને પહેલા એક્સેસ ચાલુ કરો."
                    LaprriLanguage.HINDI -> "फ़ोन एक्सेस अभी बंद है। कृपया पहले एक्सेस ऑन करें।"
                    LaprriLanguage.ENGLISH -> "Phone access is currently off. Please turn on access first."
                }
                deliverResponse("⚠️ Phone access is turned off.", offMsg)
                return
            }

            // Check if this specific app is permitted
            if (isAppAllowed(detectedApp.packageName)) {
                val launchMsg = when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> "જી સર, ${detectedApp.appName} ખોલી રહી છું..."
                    LaprriLanguage.HINDI -> "जी सर, ${detectedApp.appName} ओपन कर रही हूँ..."
                    LaprriLanguage.ENGLISH -> "Opening ${detectedApp.appName} now, Sir..."
                }
                deliverResponse("🚀 Opening ${detectedApp.appName}...", launchMsg)
                mainHandler.postDelayed({
                    launchAppByPackage(detectedApp.packageName, detectedApp.appName)
                }, 800)
            } else {
                // Not permitted yet -> Ask user for permission in chosen language!
                _pendingPermissionApp.value = detectedApp
                val permMsg = when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> "સર, ${detectedApp.appName} ની પરમિશન મારી પાસે નથી. શું હું આ એપની પરમિશન આપી દઉં?"
                    LaprriLanguage.HINDI -> "सर, ${detectedApp.appName} की परमिशन मेरे पास नहीं है। क्या मैं इसकी परमिशन अलाउ कर दूँ?"
                    LaprriLanguage.ENGLISH -> "Sir, I don't have permission for ${detectedApp.appName}. Should I grant permission for it?"
                }
                deliverResponse("⚠️ Permission needed for ${detectedApp.appName}", permMsg)
            }
            return
        }

        // 10. Default: General Wake Response in current language
        triggerWakeResponse(inputText)
    }

    private fun isAffirmative(text: String): Boolean {
        return text.contains("haan") || text.contains("ha") || text.contains("yes") ||
               text.contains("de do") || text.contains("allow") || text.contains("chalu") ||
               text.contains("theek hai") || text.contains("ok") || text.contains("kar do") ||
               text.contains("bhejo") || text.contains("open") || text.contains("sure") ||
               text.contains("હા") || text.contains("આપો") || text.contains("આપી દો") ||
               text.contains("ચાલુ કરો") || text.contains("કરી દો") || text.contains("ઠીક છે")
    }

    private fun isNegative(text: String): Boolean {
        return text.contains("nahi") || text.contains("no") || text.contains("cancel") ||
               text.contains("mat do") || text.contains("rehne do") || text.contains("don't") ||
               text.contains("band") || text.contains("stop") ||
               text.contains("ના") || text.contains("નથી") || text.contains("રહેવા દો") ||
               text.contains("ના આપો") || text.contains("બંધ")
    }

    /**
     * Finds any matching app on the phone from spoken text query in Gujarati, Hindi or English
     */
    private fun findAppInQuery(spokenText: String): AppInfo? {
        val apps = _installedApps.value
        if (apps.isEmpty()) return null

        // Clean query by removing common prefix & suffix words across languages
        var query = spokenText.lowercase()
        for (kw in wakeWordKeywords) query = query.replace(kw, "")
        query = query.replace("open", "")
                     .replace("kholo", "")
                     .replace("chalao", "")
                     .replace("chalu karo", "")
                     .replace("chalu", "")
                     .replace("start", "")
                     .replace("launch", "")
                     .replace("dikhao", "")
                     .replace("ખોલો", "")
                     .replace("ચાલુ કરો", "")
                     .replace("ચાલુ", "")
                     .replace("બતાવો", "")
                     .replace("permission", "")
                     .replace("પરમિશન", "")
                     .replace("access", "")
                     .replace("એક્સેસ", "")
                     .replace("hata do", "")
                     .replace("band karo", "")
                     .replace("હટાવો", "")
                     .replace("બંધ કરો", "")
                     .replace("remove", "")
                     .replace("revoke", "")
                     .replace("de do", "")
                     .replace("aapo", "")
                     .replace("aapi do", "")
                     .replace("આપો", "")
                     .replace("આપી દો", "")
                     .replace("allow", "")
                     .replace("ki", "")
                     .replace("ko", "")
                     .replace("ka", "")
                     .replace("ni", "")
                     .replace("ne", "")
                     .replace("nu", "")
                     .replace("ની", "")
                     .replace("ને", "")
                     .replace("નું", "")
                     .replace("app", "")
                     .replace("application", "")
                     .replace("એપ", "")
                     .trim()

        if (query.isBlank()) return null

        // 1. Alias Matching
        val aliasMatch = matchAlias(query, apps)
        if (aliasMatch != null) return aliasMatch

        // 2. Exact match against App Name
        val exact = apps.firstOrNull { it.appName.lowercase() == query }
        if (exact != null) return exact

        // 3. Substring / Prefix match
        val partial = apps.firstOrNull { 
            val name = it.appName.lowercase()
            name.contains(query) || query.contains(name)
        }
        if (partial != null) return partial

        // 4. Package Name Substring match (e.g. com.whatsapp -> whatsapp)
        val pkgMatch = apps.firstOrNull {
            it.packageName.lowercase().contains(query)
        }
        return pkgMatch
    }

    private fun matchAlias(query: String, apps: List<AppInfo>): AppInfo? {
        val aliasMap = mapOf(
            "whatsapp" to listOf("whatsapp", "whats app", "watsapp", "વોટ્સએપ", "વૉટ્સએપ", "व्हाट्सएप"),
            "youtube" to listOf("youtube", "you tube", "yt", "યૂટ્યૂબ", "યુટ્યુબ", "यूट्यूब"),
            "instagram" to listOf("instagram", "insta", "ig", "ઇન્સ્ટાગ્રામ", "ઇન્સ્ટા", "इंस्टाग्राम"),
            "chrome" to listOf("chrome", "browser", "internet", "ક્રોમ", "બ્રાઉઝર", "क्रोम"),
            "camera" to listOf("camera", "cam", "kamera", "કેમેરા", "કેમેરો", "कैमरा"),
            "gallery" to listOf("gallery", "photos", "photo", "tasveer", "album", "ગેલેરી", "ફોટા", "गैलरी"),
            "gmail" to listOf("gmail", "google mail", "જીમેઇલ", "જીમેલ", "जीमेल"),
            "maps" to listOf("maps", "google maps", "map", "મેપ્સ", "નકશો", "मैप्स"),
            "settings" to listOf("settings", "setting", "phone settings", "સેટિંગ્સ", "સેટિંગ", "सेटिंग्स"),
            "calculator" to listOf("calculator", "calc", "hisaab", "કેલ્ક્યુલેટર", "ગણતરી", "कैलकुलेटर"),
            "contacts" to listOf("contacts", "contact", "phonebook", "કોન્ટેક્ટ્સ", "કોન્ટેક્ટ", "कॉन्टेक्ट्स"),
            "spotify" to listOf("spotify", "music", "gaana", "સંગીત", "ગાના", "स्पॉटिफाई"),
            "facebook" to listOf("facebook", "fb", "ફેસબુક", "फेसबुक"),
            "telegram" to listOf("telegram", "tg", "ટેલિગ્રામ", "टेलीग्राम"),
            "paytm" to listOf("paytm", "પેટીએમ", "પેટીએમ"),
            "gpay" to listOf("gpay", "google pay", "googlepay", "જીપે"),
            "phonepe" to listOf("phonepe", "phone pe", "ફોનપે", "फ़ोनपे"),
            "clock" to listOf("clock", "alarm", "ghadi", "ઘડિયાળ", "અલાર્મ", "घड़ी"),
            "files" to listOf("files", "file manager", "my files", "ફાઇલ્સ", "फ़ाइल्स"),
            "calendar" to listOf("calendar", "pancahang", "કેલેન્ડર", "પંચાંગ", "कैलेंडर")
        )

        for ((targetKey, aliases) in aliasMap) {
            if (aliases.any { query.contains(it) || it == query }) {
                val found = apps.firstOrNull { app ->
                    val name = app.appName.lowercase()
                    val pkg = app.packageName.lowercase()
                    name.contains(targetKey) || pkg.contains(targetKey)
                }
                if (found != null) return found
            }
        }
        return null
    }

    private fun launchAppByPackage(packageName: String, appName: String) {
        try {
            val launchIntent = packageManager.getLaunchIntentForPackage(packageName)?.apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            if (launchIntent != null) {
                context.startActivity(launchIntent)
            } else {
                when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> speakText("સર, $appName ઓપન નથી થઈ શકી.")
                    LaprriLanguage.HINDI -> speakText("सर, $appName ओपन नहीं हो पाई।")
                    LaprriLanguage.ENGLISH -> speakText("Sir, unable to open $appName.")
                }
            }
        } catch (_: Exception) {
            when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> speakText("સર, $appName ઓપન કરવામાં સમસ્યા આવી.")
                LaprriLanguage.HINDI -> speakText("सर, $appName ओपन करने में दिक्कत आई।")
                LaprriLanguage.ENGLISH -> speakText("Sir, there was an issue launching $appName.")
            }
        }
    }

    private fun handleCallCommand(text: String) {
        stopListening()
        val digits = text.filter { it.isDigit() }
        val intent = if (digits.length >= 3) {
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        } else {
            Intent(Intent.ACTION_DIAL).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        }

        val speech = when (_currentLanguage.value) {
            LaprriLanguage.GUJARATI -> "કોલિંગ ઓપન કરી રહી છું..."
            LaprriLanguage.HINDI -> "कॉलिंग ओपन कर रही हूँ..."
            LaprriLanguage.ENGLISH -> "Opening phone dialer..."
        }
        deliverResponse("📞 Opening Dialer / Calling...", speech)
        mainHandler.postDelayed({
            try {
                context.startActivity(intent)
            } catch (_: Exception) {
                speakText("Dialer not available.")
            }
        }, 800)
    }

    private fun handleSmsCommand() {
        stopListening()
        val smsIntent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val speech = when (_currentLanguage.value) {
            LaprriLanguage.GUJARATI -> "મેસેજિંગ ઓપન કરી રહી છું..."
            LaprriLanguage.HINDI -> "मैसेजिंग ओपन कर रही हूँ..."
            LaprriLanguage.ENGLISH -> "Opening messaging..."
        }
        deliverResponse("💬 Opening Messages...", speech)
        mainHandler.postDelayed({
            try {
                context.startActivity(smsIntent)
            } catch (_: Exception) {
                speakText("Messages not available.")
            }
        }, 800)
    }

    private fun handleLocationCommand() {
        stopListening()
        val mapIntent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=my+location")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val speech = when (_currentLanguage.value) {
            LaprriLanguage.GUJARATI -> "લોકેશન અને મેપ્સ ઓપન કરી રહી છું..."
            LaprriLanguage.HINDI -> "लोकेशन और मैप्स ओपन कर रही हूँ..."
            LaprriLanguage.ENGLISH -> "Opening location and maps..."
        }
        deliverResponse("📍 Opening Location & Maps...", speech)
        mainHandler.postDelayed({
            try {
                context.startActivity(mapIntent)
            } catch (_: Exception) {
                speakText("Maps not available.")
            }
        }, 800)
    }

    private fun handleMailCommand() {
        stopListening()
        val mailIntent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val speech = when (_currentLanguage.value) {
            LaprriLanguage.GUJARATI -> "મેઇલ ઓપન કરી રહી છું..."
            LaprriLanguage.HINDI -> "मेल ओपन कर रही हूँ..."
            LaprriLanguage.ENGLISH -> "Opening email..."
        }
        deliverResponse("✉️ Opening Mail / Email...", speech)
        mainHandler.postDelayed({
            try {
                context.startActivity(mailIntent)
            } catch (_: Exception) {
                speakText("Email app not available.")
            }
        }, 800)
    }

    fun confirmPendingPermission(allow: Boolean) {
        val pendingApp = _pendingPermissionApp.value ?: return
        if (allow) {
            grantPermissionForApp(pendingApp)
            _pendingPermissionApp.value = null
            val speech = when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> "જી સર, ${pendingApp.appName} ને પરમિશન આપી દીધી છે. હવે ઓપન કરી રહી છું..."
                LaprriLanguage.HINDI -> "जी सर, ${pendingApp.appName} को परमिशन दे दी गई है। अब ओपन कर रही हूँ..."
                LaprriLanguage.ENGLISH -> "Permission granted for ${pendingApp.appName}. Opening now..."
            }
            deliverResponse("✅ Permission granted for ${pendingApp.appName}. Opening now...", speech)
            mainHandler.postDelayed({
                launchAppByPackage(pendingApp.packageName, pendingApp.appName)
            }, 800)
        } else {
            _pendingPermissionApp.value = null
            val speech = when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> "ઠીક છે સર, પરમિશન નથી આપી."
                LaprriLanguage.HINDI -> "ठीक है सर, परमिशन नहीं दी गई।"
                LaprriLanguage.ENGLISH -> "Alright Sir, permission denied."
            }
            deliverResponse("❌ Permission denied for ${pendingApp.appName}.", speech)
        }
    }

    fun triggerWakeResponse(spokenPhrase: String = "Laprri") {
        stopListening()

        if (customAudioFiles.isNotEmpty()) {
            val file = customAudioFiles.random()
            playAudioFile(file, "✨ Laprri heard you! Playing voice response...")
            addChatMessage("✨ Laprri voice response playing...", isUser = false)
            return
        }

        val responses = when (_currentLanguage.value) {
            LaprriLanguage.GUJARATI -> generalWakeResponsesGujarati
            LaprriLanguage.HINDI -> generalWakeResponsesHindi
            LaprriLanguage.ENGLISH -> generalWakeResponsesEnglish
        }

        var nextIdx: Int
        do {
            nextIdx = (0 until responses.size).random()
        } while (nextIdx == lastResponseIndex && responses.size > 1)
        lastResponseIndex = nextIdx

        val response = responses[nextIdx]
        deliverResponse(response)
    }

    fun setCustomWallpaper(uri: Uri) {
        try {
            val wpFile = File(context.filesDir, "custom_wallpaper_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(wpFile).use { output ->
                    input.copyTo(output)
                }
            }
            sharedPreferences.edit().putString("custom_wallpaper_path", wpFile.absolutePath).apply()
            _customWallpaperPath.value = wpFile.absolutePath
            when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> speakText("વોલપેપર સફળતાપૂર્વક સેટ થઈ ગયું છે.")
                LaprriLanguage.HINDI -> speakText("वॉलपेपर सफलतापूर्वक सेट हो गया है।")
                LaprriLanguage.ENGLISH -> speakText("Custom wallpaper set successfully.")
            }
            loadUploadedFiles()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setCustomWallpaper(filePath: String) {
        try {
            val file = File(filePath)
            if (file.exists()) {
                sharedPreferences.edit().putString("custom_wallpaper_path", file.absolutePath).apply()
                _customWallpaperPath.value = file.absolutePath
                when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> speakText("વોલપેપર સફળતાપૂર્વક સેટ થઈ ગયું છે.")
                    LaprriLanguage.HINDI -> speakText("वॉलपेपर सफलतापूर्वक सेट हो गया है।")
                    LaprriLanguage.ENGLISH -> speakText("Custom wallpaper set successfully.")
                }
                loadUploadedFiles()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun playUploadedAudio(item: UploadedFileItem) {
        try {
            val file = File(item.path)
            if (file.exists()) {
                playAudioFile(file, "Playing ${item.name}")
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun removeCustomWallpaper() {
        try {
            val currentPath = _customWallpaperPath.value
            if (currentPath != null) {
                val f = File(currentPath)
                if (f.exists()) f.delete()
            }
            sharedPreferences.edit().remove("custom_wallpaper_path").apply()
            _customWallpaperPath.value = null
            when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> speakText("કસ્ટમ વોલપેપર હટાવી દીધું છે.")
                LaprriLanguage.HINDI -> speakText("कस्टम वॉलपेपर हटा दिया गया है।")
                LaprriLanguage.ENGLISH -> speakText("Custom wallpaper removed.")
            }
            loadUploadedFiles()
        } catch (_: Exception) {}
    }

    fun uploadFile(uri: Uri, suggestedName: String? = null) {
        try {
            val uploadsDir = File(context.filesDir, "uploads")
            if (!uploadsDir.exists()) uploadsDir.mkdirs()

            val mimeType = context.contentResolver.getType(uri)?.lowercase() ?: ""
            val rawName = suggestedName ?: "file_${System.currentTimeMillis()}"
            val extension = when {
                mimeType.contains("image/jpeg") || mimeType.contains("jpg") -> "jpg"
                mimeType.contains("image/png") -> "png"
                mimeType.contains("image/webp") -> "webp"
                mimeType.contains("audio/mpeg") || mimeType.contains("audio/mp3") -> "mp3"
                mimeType.contains("audio/wav") -> "wav"
                mimeType.contains("audio/ogg") -> "ogg"
                mimeType.contains("audio/m4a") || mimeType.contains("audio/mp4") -> "m4a"
                mimeType.contains("pdf") -> "pdf"
                else -> rawName.substringAfterLast(".", "dat")
            }

            val safeName = if (rawName.contains(".")) rawName else "$rawName.$extension"
            val destFile = File(uploadsDir, "${System.currentTimeMillis()}_$safeName")

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }

            // If audio, also add to custom audio clips
            if (mimeType.startsWith("audio/") || extension in listOf("mp3", "wav", "ogg", "m4a", "aac")) {
                customAudioFiles.add(destFile)
                _hasCustomAudio.value = true
            }

            // If image, also update custom wallpaper
            if (mimeType.startsWith("image/") || extension in listOf("jpg", "jpeg", "png", "webp")) {
                _customWallpaperPath.value = destFile.absolutePath
                sharedPreferences.edit().putString("custom_wallpaper_path", destFile.absolutePath).apply()
            }

            loadUploadedFiles()

            when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> speakText("ફાઈલ સફળતાપૂર્વક અપલોડ થઈ ગઈ છે.")
                LaprriLanguage.HINDI -> speakText("फ़ाइल सफलतापूर्वक अपलोड हो गई है।")
                LaprriLanguage.ENGLISH -> speakText("File uploaded successfully.")
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun deleteUploadedFile(item: UploadedFileItem) {
        try {
            val file = File(item.path)
            if (file.exists()) file.delete()
            if (_customWallpaperPath.value == item.path) {
                removeCustomWallpaper()
            }
            customAudioFiles.removeAll { it.absolutePath == item.path }
            if (customAudioFiles.isEmpty()) {
                _hasCustomAudio.value = false
            }
            loadUploadedFiles()
        } catch (_: Exception) {}
    }

    fun loadUploadedFiles() {
        try {
            val list = mutableListOf<UploadedFileItem>()
            val uploadsDir = File(context.filesDir, "uploads")
            if (uploadsDir.exists()) {
                uploadsDir.listFiles()?.forEach { file ->
                    val ext = file.extension.lowercase()
                    val type = when {
                        ext in listOf("jpg", "jpeg", "png", "webp", "gif") -> UploadedFileType.IMAGE
                        ext in listOf("mp3", "wav", "m4a", "ogg", "aac") -> UploadedFileType.AUDIO
                        ext in listOf("pdf", "doc", "docx", "txt", "zip") -> UploadedFileType.DOCUMENT
                        else -> UploadedFileType.OTHER
                    }
                    val sizeKb = file.length() / 1024
                    val sizeFormatted = if (sizeKb > 1024) "${sizeKb / 1024} MB" else "$sizeKb KB"
                    list.add(
                        UploadedFileItem(
                            id = file.name,
                            name = file.name.substringAfter("_"),
                            path = file.absolutePath,
                            fileType = type,
                            sizeBytes = file.length(),
                            formattedSize = sizeFormatted,
                            timestamp = file.lastModified()
                        )
                    )
                }
            }

            val wpPath = _customWallpaperPath.value
            if (wpPath != null) {
                val wpFile = File(wpPath)
                if (wpFile.exists() && list.none { it.path == wpPath }) {
                    val sizeKb = wpFile.length() / 1024
                    list.add(
                        UploadedFileItem(
                            id = wpFile.name,
                            name = "Wallpaper (${wpFile.name})",
                            path = wpFile.absolutePath,
                            fileType = UploadedFileType.IMAGE,
                            sizeBytes = wpFile.length(),
                            formattedSize = "${sizeKb} KB",
                            timestamp = wpFile.lastModified()
                        )
                    )
                }
            }

            _uploadedFiles.value = list.sortedByDescending { it.timestamp }
        } catch (_: Exception) {}
    }

    fun addCustomAudioClip(uri: Uri, title: String = "Custom Voice") {
        try {
            val audioDir = File(context.filesDir, "custom_voices")
            if (!audioDir.exists()) audioDir.mkdirs()
            val destFile = File(audioDir, "voice_${System.currentTimeMillis()}.${context.contentResolver.getType(uri)?.substringAfterLast("/") ?: "mp3"}")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }
            customAudioFiles.add(destFile)
            _hasCustomAudio.value = true
            _currentDialogue.value = "Custom Voice Note added: $title"
            playAudioFile(destFile, title)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun playAudioFile(file: File, label: String = "Playing custom audio") {
        if (!_isVoiceEnabled.value) return
        stop()
        try {
            checkBluetoothAudioRouting()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(if (_isBluetoothConnected.value) AudioAttributes.USAGE_VOICE_COMMUNICATION else AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(file.absolutePath)
                setOnPreparedListener {
                    _isSpeaking.value = true
                    _currentDialogue.value = label
                    start()
                }
                setOnCompletionListener {
                    _isSpeaking.value = false
                    releaseMediaPlayer()
                    restartListeningWithDelay(600)
                }
                setOnErrorListener { _, _, _ ->
                    _isSpeaking.value = false
                    releaseMediaPlayer()
                    restartListeningWithDelay(600)
                    true
                }
                prepareAsync()
            }
        } catch (_: Exception) {
            _isSpeaking.value = false
            restartListeningWithDelay(600)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsInitialized = true
            setupVoiceEngine()

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                    restartListeningWithDelay(600)
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                    restartListeningWithDelay(600)
                }
            })

            if (_isVoiceEnabled.value) {
                when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> speakText("નમસ્તે સર! હું લપરી છું. તમે કોઈપણ એપનું નામ બોલીને તેને ખોલી શકો છો.")
                    LaprriLanguage.HINDI -> speakText("नमस्ते सर! मैं लपरी हूँ। आप किसी भी ऐप का नाम बोलकर उसे ओपन कर सकते हैं।")
                    LaprriLanguage.ENGLISH -> speakText("Hello Sir! I am Laprri. You can speak any app name to open it instantly.")
                }
            }
        }
    }

    private fun setupVoiceEngine() {
        val ttsInstance = tts ?: return
        try {
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                .build()
            ttsInstance.setAudioAttributes(audioAttributes)

            val currentLang = _currentLanguage.value
            val targetLocale = when (currentLang) {
                LaprriLanguage.GUJARATI -> Locale("gu", "IN")
                LaprriLanguage.HINDI -> Locale("hi", "IN")
                LaprriLanguage.ENGLISH -> Locale("en", "IN")
            }

            val result = ttsInstance.setLanguage(targetLocale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // If specific regional voice pack is missing, fallback to available Indian/English locale
                ttsInstance.language = Locale("hi", "IN")
            }

            val availableVoices = ttsInstance.voices
            val femaleVoice = availableVoices?.firstOrNull { voice ->
                val name = voice.name.lowercase()
                !voice.isNetworkConnectionRequired && (
                    (currentLang == LaprriLanguage.GUJARATI && (name.contains("gu-in") || name.contains("gujarati"))) ||
                    (currentLang == LaprriLanguage.HINDI && (name.contains("hi-in") || name.contains("female") || name.contains("hi-in-x-cfn"))) ||
                    (currentLang == LaprriLanguage.ENGLISH && (name.contains("en-in") || name.contains("en-us") || name.contains("female")))
                )
            } ?: availableVoices?.firstOrNull { voice ->
                voice.name.lowercase().contains("female")
            }

            if (femaleVoice != null) {
                ttsInstance.voice = femaleVoice
            }

            ttsInstance.setPitch(1.20f)
            ttsInstance.setSpeechRate(0.95f)
        } catch (_: Exception) {
            ttsInstance.language = Locale("hi", "IN")
            ttsInstance.setPitch(1.20f)
            ttsInstance.setSpeechRate(0.95f)
        }
    }

    fun toggleVoice() {
        val next = !_isVoiceEnabled.value
        _isVoiceEnabled.value = next
        if (!next) {
            stop()
        } else {
            speakText("Voice enabled! Laprri is listening...")
        }
    }

    private fun speakText(text: String) {
        if (!isTtsInitialized || tts == null) return
        stop()
        checkBluetoothAudioRouting()
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "laprri_voice_${System.currentTimeMillis()}")
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "laprri_voice_${System.currentTimeMillis()}")
    }

    private fun releaseMediaPlayer() {
        try {
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (_: Exception) {}
    }

    fun stop() {
        try {
            tts?.stop()
            if (mediaPlayer?.isPlaying == true) {
                mediaPlayer?.stop()
            }
            releaseMediaPlayer()
        } catch (_: Exception) {}
        _isSpeaking.value = false
    }

    fun shutdown() {
        stop()
        mainHandler.removeCallbacksAndMessages(null)
        if (isReceiverRegistered) {
            try {
                context.unregisterReceiver(bluetoothReceiver)
            } catch (_: Exception) {}
            isReceiverRegistered = false
        }
        try {
            if (bluetoothHeadset != null && bluetoothAdapter != null) {
                bluetoothAdapter?.closeProfileProxy(BluetoothProfile.HEADSET, bluetoothHeadset)
            }
        } catch (_: Exception) {}
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (_: Exception) {}
        tts?.shutdown()
        tts = null
        isTtsInitialized = false
        onBluetoothDisconnected()
    }
}
