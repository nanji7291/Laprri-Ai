package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Scheme - Mint Anime & Beach Summer Theme
val AiPrimaryLight = Color(0xFF0D9488) // Vibrant Mint Teal
val AiOnPrimaryLight = Color(0xFFFFFFFF)
val AiPrimaryContainerLight = Color(0xFFCCFBF1)
val AiOnPrimaryContainerLight = Color(0xFF115E59)

val AiSecondaryLight = Color(0xFFE11D48) // Vibrant Coral Rose
val AiOnSecondaryLight = Color(0xFFFFFFFF)
val AiSecondaryContainerLight = Color(0xFFFFE4E6)
val AiOnSecondaryContainerLight = Color(0xFF9F1239)

val AiTertiaryLight = Color(0xFFD97706) // Sunny Amber
val AiOnTertiaryLight = Color(0xFFFFFFFF)

val AiBackgroundLight = Color(0xFFF6FBFB)
val AiSurfaceLight = Color(0xFFFFFFFF)
val AiSurfaceVariantLight = Color(0xFFE6F4F4)
val AiOnSurfaceLight = Color(0xFF0F172A)
val AiOnSurfaceVariantLight = Color(0xFF334155)

// Dark Scheme - Neon Mint Cyber Ocean
val AiPrimaryDark = Color(0xFF2DD4BF) // Neon Mint
val AiOnPrimaryDark = Color(0xFF003833)
val AiPrimaryContainerDark = Color(0xFF115E59)
val AiOnPrimaryContainerDark = Color(0xFFCCFBF1)

val AiSecondaryDark = Color(0xFFFB7185) // Neon Coral
val AiOnSecondaryDark = Color(0xFF4C0519)
val AiSecondaryContainerDark = Color(0xFF881337)
val AiOnSecondaryContainerDark = Color(0xFFFFE4E6)

val AiTertiaryDark = Color(0xFFFBBF24) // Gold
val AiOnTertiaryDark = Color(0xFF451A03)

val AiBackgroundDark = Color(0xFF051319)
val AiSurfaceDark = Color(0xFF0B1F27)
val AiSurfaceVariantDark = Color(0xFF132F3B)
val AiOnSurfaceDark = Color(0xFFF1F5F9)
val AiOnSurfaceVariantDark = Color(0xFF94A3B8)

val AiCodeBgDark = Color(0xFF030D12)
val AiNeonCyan = Color(0xFF06B6D4)
val AiNeonPurple = Color(0xFF8B5CF6)
val AiNeonAmber = Color(0xFFF59E0B)
val AiNeonGreen = Color(0xFF10B981)
val AiMintGreen = Color(0xFF2DD4BF)
