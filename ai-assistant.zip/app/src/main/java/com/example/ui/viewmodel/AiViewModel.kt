package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatSessionEntity
import com.example.data.model.AiPersona
import com.example.data.repository.AiRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AiViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AiRepository

    init {
        val db = AppDatabase.getInstance(application)
        repository = AiRepository(db.chatDao())
    }

    val allSessions: StateFlow<List<ChatSessionEntity>> = repository.allSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentSessionId = MutableStateFlow<Long?>(null)
    val currentSessionId: StateFlow<Long?> = _currentSessionId.asStateFlow()

    private val _activePersona = MutableStateFlow(AiPersona.MINT_ANIME)
    val activePersona: StateFlow<AiPersona> = _activePersona.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _promptInput = MutableStateFlow("")
    val promptInput: StateFlow<String> = _promptInput.asStateFlow()

    private val _selectedImageBase64 = MutableStateFlow<String?>(null)
    val selectedImageBase64: StateFlow<String?> = _selectedImageBase64.asStateFlow()

    private val _activeTab = MutableStateFlow(0)
    val activeTab: StateFlow<Int> = _activeTab.asStateFlow()

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val currentMessages: StateFlow<List<ChatMessageEntity>> = _currentSessionId
        .flatMapLatest { sessionId ->
            if (sessionId != null) {
                repository.getMessagesForSession(sessionId)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Initialize or restore first session
        viewModelScope.launch {
            allSessions.collect { sessions ->
                if (_currentSessionId.value == null && sessions.isNotEmpty()) {
                    val latest = sessions.first()
                    _currentSessionId.value = latest.id
                    _activePersona.value = AiPersona.fromId(latest.personaId)
                }
            }
        }
    }

    fun onPromptChange(newText: String) {
        _promptInput.value = newText
    }

    fun onSelectImage(base64: String?) {
        _selectedImageBase64.value = base64
    }

    fun onClearImage() {
        _selectedImageBase64.value = null
    }

    fun setActiveTab(tabIndex: Int) {
        _activeTab.value = tabIndex
    }

    fun setPersona(persona: AiPersona) {
        _activePersona.value = persona
        val currentId = _currentSessionId.value
        if (currentId != null) {
            viewModelScope.launch {
                repository.updateSessionPersona(currentId, persona)
            }
        }
    }

    fun selectSession(sessionId: Long) {
        _currentSessionId.value = sessionId
        _activeTab.value = 0
        viewModelScope.launch {
            val session = repository.getSessionById(sessionId)
            if (session != null) {
                _activePersona.value = AiPersona.fromId(session.personaId)
            }
        }
    }

    fun createNewChat(persona: AiPersona = _activePersona.value) {
        viewModelScope.launch {
            val newId = repository.createNewSession("New Chat", persona)
            _currentSessionId.value = newId
            _activePersona.value = persona
            _promptInput.value = ""
            _selectedImageBase64.value = null
            _activeTab.value = 0
        }
    }

    fun sendMessage(customPrompt: String? = null) {
        val textToSend = (customPrompt ?: _promptInput.value).trim()
        val imageToSend = _selectedImageBase64.value

        if (textToSend.isEmpty() && imageToSend == null) return

        _promptInput.value = ""
        _selectedImageBase64.value = null
        _isLoading.value = true

        viewModelScope.launch {
            var sessionId = _currentSessionId.value
            if (sessionId == null) {
                sessionId = repository.createNewSession("New Chat", _activePersona.value)
                _currentSessionId.value = sessionId
            }

            repository.sendMessage(
                sessionId = sessionId,
                userPrompt = if (textToSend.isEmpty()) "Describe this image in detail." else textToSend,
                imageBase64 = imageToSend,
                persona = _activePersona.value
            )

            _isLoading.value = false
        }
    }

    fun runToolWithPrompt(prompt: String, persona: AiPersona = AiPersona.GENERAL) {
        _activePersona.value = persona
        _activeTab.value = 0
        viewModelScope.launch {
            val newId = repository.createNewSession(prompt.take(24) + "...", persona)
            _currentSessionId.value = newId
            sendMessage(prompt)
        }
    }

    fun deleteSession(sessionId: Long) {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            if (_currentSessionId.value == sessionId) {
                _currentSessionId.value = null
            }
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAll()
            _currentSessionId.value = null
        }
    }
}
