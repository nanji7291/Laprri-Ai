package com.example.model

enum class UploadedFileType {
    IMAGE,
    AUDIO,
    DOCUMENT,
    OTHER
}

data class UploadedFileItem(
    val id: String,
    val name: String,
    val path: String,
    val fileType: UploadedFileType,
    val sizeBytes: Long,
    val formattedSize: String,
    val timestamp: Long
)
