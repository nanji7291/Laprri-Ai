package com.example.model

data class AppInfo(
    val appName: String,
    val packageName: String,
    val isAllowed: Boolean = false
)
