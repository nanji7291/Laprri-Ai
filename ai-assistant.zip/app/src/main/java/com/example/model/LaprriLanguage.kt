package com.example.model

enum class LaprriLanguage(
    val code: String,
    val displayName: String,
    val nativeName: String,
    val localeTag: String
) {
    GUJARATI("gu", "Gujarati", "ગુજરાતી", "gu-IN"),
    HINDI("hi", "Hindi", "हिन्दी", "hi-IN"),
    ENGLISH("en", "English", "English", "en-IN");

    companion object {
        fun fromCode(code: String): LaprriLanguage {
            return entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: HINDI
        }
    }
}
