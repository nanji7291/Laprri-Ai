package com.example.data.repository

import android.util.Log
import com.example.BuildConfig
import com.example.data.api.RetrofitClient
import com.example.data.local.ChatDao
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatSessionEntity
import com.example.data.model.AiPersona
import com.example.data.model.Content
import com.example.data.model.GenerateContentRequest
import com.example.data.model.GenerationConfig
import com.example.data.model.InlineData
import com.example.data.model.Part
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class AiRepository(private val chatDao: ChatDao) {

    val allSessions: Flow<List<ChatSessionEntity>> = chatDao.getAllSessions()

    fun getMessagesForSession(sessionId: Long): Flow<List<ChatMessageEntity>> {
        return chatDao.getMessagesForSession(sessionId)
    }

    suspend fun getSessionById(sessionId: Long): ChatSessionEntity? = withContext(Dispatchers.IO) {
        chatDao.getSessionById(sessionId)
    }

    suspend fun createNewSession(title: String = "New Chat", persona: AiPersona = AiPersona.GENERAL): Long =
        withContext(Dispatchers.IO) {
            val session = ChatSessionEntity(
                title = title,
                personaId = persona.id,
                createdAt = System.currentTimeMillis(),
                lastUpdatedAt = System.currentTimeMillis()
            )
            chatDao.insertSession(session)
        }

    suspend fun updateSessionTitle(sessionId: Long, newTitle: String) = withContext(Dispatchers.IO) {
        val session = chatDao.getSessionById(sessionId)
        if (session != null) {
            chatDao.updateSession(session.copy(title = newTitle, lastUpdatedAt = System.currentTimeMillis()))
        }
    }

    suspend fun updateSessionPersona(sessionId: Long, persona: AiPersona) = withContext(Dispatchers.IO) {
        val session = chatDao.getSessionById(sessionId)
        if (session != null) {
            chatDao.updateSession(session.copy(personaId = persona.id, lastUpdatedAt = System.currentTimeMillis()))
        }
    }

    suspend fun deleteSession(sessionId: Long) = withContext(Dispatchers.IO) {
        chatDao.deleteMessagesForSession(sessionId)
        chatDao.deleteSession(sessionId)
    }

    suspend fun clearAll() = withContext(Dispatchers.IO) {
        chatDao.clearAllMessages()
        chatDao.clearAllSessions()
    }

    suspend fun sendMessage(
        sessionId: Long,
        userPrompt: String,
        imageBase64: String?,
        persona: AiPersona
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            // 1. Insert user message in database
            val userMsg = ChatMessageEntity(
                sessionId = sessionId,
                sender = "USER",
                text = userPrompt,
                imageBase64 = imageBase64,
                timestamp = System.currentTimeMillis()
            )
            chatDao.insertMessage(userMsg)

            // Update session title if default
            val currentSession = chatDao.getSessionById(sessionId)
            if (currentSession != null && (currentSession.title == "New Chat" || currentSession.title.isBlank())) {
                val generatedTitle = if (userPrompt.length > 28) userPrompt.take(28) + "..." else userPrompt
                chatDao.updateSession(currentSession.copy(title = generatedTitle, lastUpdatedAt = System.currentTimeMillis()))
            } else if (currentSession != null) {
                chatDao.updateSession(currentSession.copy(lastUpdatedAt = System.currentTimeMillis()))
            }

            // 2. Prepare past context (last 8 messages)
            val pastMessages = chatDao.getMessagesListForSession(sessionId).takeLast(8)
            val contentsList = mutableListOf<Content>()

            for (msg in pastMessages) {
                val role = if (msg.sender == "USER") "user" else "model"
                val parts = mutableListOf<Part>()
                if (!msg.imageBase64.isNullOrBlank()) {
                    parts.add(Part(inlineData = InlineData(mimeType = "image/jpeg", data = msg.imageBase64)))
                }
                if (msg.text.isNotBlank()) {
                    parts.add(Part(text = msg.text))
                }
                if (parts.isNotEmpty()) {
                    contentsList.add(Content(role = role, parts = parts))
                }
            }

            if (contentsList.isEmpty()) {
                val currentParts = mutableListOf<Part>()
                if (!imageBase64.isNullOrBlank()) {
                    currentParts.add(Part(inlineData = InlineData(mimeType = "image/jpeg", data = imageBase64)))
                }
                currentParts.add(Part(text = userPrompt))
                contentsList.add(Content(role = "user", parts = currentParts))
            }

            // 3. System instruction based on persona
            val systemInstruction = Content(
                parts = listOf(Part(text = persona.systemPrompt))
            )

            val request = GenerateContentRequest(
                contents = contentsList,
                generationConfig = GenerationConfig(
                    temperature = 0.7f,
                    topP = 0.95f,
                    topK = 40
                ),
                systemInstruction = systemInstruction
            )

            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                // Fallback simulation/demonstration if key isn't configured in environment
                val fallbackResponse = getOfflineSmartResponse(userPrompt, persona, imageBase64 != null)
                val aiMsg = ChatMessageEntity(
                    sessionId = sessionId,
                    sender = "AI",
                    text = fallbackResponse,
                    timestamp = System.currentTimeMillis(),
                    isError = false
                )
                chatDao.insertMessage(aiMsg)
                return@withContext Result.success(fallbackResponse)
            }

            val response = RetrofitClient.geminiService.generateContent(apiKey, request)
            val aiText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: response.error?.message
                ?: "I processed your request, but could not generate a response text."

            // Save AI reply to Room
            val aiMsg = ChatMessageEntity(
                sessionId = sessionId,
                sender = "AI",
                text = aiText,
                timestamp = System.currentTimeMillis(),
                isError = false
            )
            chatDao.insertMessage(aiMsg)
            Result.success(aiText)
        } catch (e: Exception) {
            Log.e("AiRepository", "Gemini API error: ${e.localizedMessage}", e)
            val errText = "⚠️ Error communicating with AI: ${e.localizedMessage ?: "Unknown network error"}. Please ensure your internet connection is active."
            val errMessage = ChatMessageEntity(
                sessionId = sessionId,
                sender = "AI",
                text = errText,
                timestamp = System.currentTimeMillis(),
                isError = true
            )
            chatDao.insertMessage(errMessage)
            Result.failure(e)
        }
    }

    private fun getOfflineSmartResponse(prompt: String, persona: AiPersona, hasImage: Boolean): String {
        val lower = prompt.lowercase()
        return when {
            hasImage -> "📸 **Image Analysis**: I received your image! When connected with a live Gemini API Key, I can extract text, explain diagrams, identify objects, and solve homework step-by-step."
            lower.contains("namaste") || lower.contains("hello") || lower.contains("hi") || lower.contains("kese ho") -> {
                "Namaste! 🙏 Main aapka smart AI Assistant hoon. Main aapke sawalon ke jawab de sakta hoon, coding me madad kar sakta hoon, emails/articles likh sakta hoon, aur Hindi/English me baat kar sakta hoon. Aaj main aapki kya madad karoon?"
            }
            persona == AiPersona.CODE_EXPERT || lower.contains("code") || lower.contains("python") || lower.contains("kotlin") -> {
                """
                Here is a clean code example based on your query:
                
                ```kotlin
                // Modern Kotlin Coroutine & Flow pattern
                fun fetchAiInsights(): Flow<AiResponse> = flow {
                    emit(AiResponse.Loading)
                    val result = apiService.generateContent(...)
                    emit(AiResponse.Success(result))
                }.catch { e ->
                    emit(AiResponse.Error(e.message))
                }
                ```
                
                💡 **Key Takeaways:**
                - Non-blocking execution on `Dispatchers.IO`
                - Reactive emission through Jetpack Compose state
                - Safe exception handling with graceful fallbacks
                """.trimIndent()
            }
            persona == AiPersona.CREATIVE_WRITER || lower.contains("shayari") || lower.contains("poem") -> {
                """
                ✨ **आपके लिए खूबसूरत शायरी:**
                
                *मंजिलें भी जिद्दी हैं, रास्ते भी जिद्दी हैं,*
                *देखते हैं कल क्या होगा, हौसले भी तो जिद्दी हैं!*
                
                ---
                चाहे कितनी भी मुश्किलें हों, नई तकनीक और ज्ञान के साथ आगे बढ़ते रहें!
                """.trimIndent()
            }
            else -> {
                """
                🤖 **AI Assistant Response:**
                
                I have analyzed your prompt: *"$prompt"*.
                
                ### Key Insights:
                1. **Smart Understanding**: Your request is noted and categorized under ${persona.displayName}.
                2. **Instant Assistance**: You can ask for code explanations, essay drafting, math solutions, language translations, or attach images for visual OCR.
                3. **Language Flexibility**: You can communicate seamlessly in English, Hindi, or Hinglish!
                
                Feel free to ask follow-up questions or test any of our specialized AI tools!
                """.trimIndent()
            }
        }
    }
}
